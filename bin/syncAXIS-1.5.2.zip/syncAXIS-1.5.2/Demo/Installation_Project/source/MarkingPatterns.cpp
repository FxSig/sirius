/*
***************************************************************************
File: MarkingPatterns.cpp

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#include "MarkingPatterns.h"

constexpr double PI = Constants::PI;
constexpr double EPSILON = Constants::EPSILON;

#include <cmath>

Command2D::Command2D()
    : Command2D(CommandType::JUMP, CartesianCoordinates())
{
};

Command2D::Command2D(CommandType SetType, const CartesianCoordinates& SetTarget)
    : Type(SetType)
    , Target(SetTarget)
{
}


CommandListType mergeCommandLists(const std::vector<CommandListType>& Elements)
{
    CommandListType CommandList;
    for (auto& It : Elements)
    {
        CommandList = mergeCommandLists(It, CommandList);
    }
    return CommandList;
}

CommandListType mergeCommandLists(const CommandListType& List1, const CommandListType& List2)
{
    CommandListType CommandList;
    for (auto& It : List1)
    {
        CommandList.push_back(It);
    }
    for (auto& It : List2)
    {
        CommandList.push_back(It);
    }
    return CommandList;
}

void appendCommandList(CommandListType& ResultingList, const CommandListType& InputList)
{
    for (auto& It : InputList)
    {
        ResultingList.push_back(It);
    }
}

const Command2D& getHomeJump()
{
    static Command2D HomeJump(CommandType::JUMP, CartesianCoordinates());
    return HomeJump;
}

Command2D createWaitCommand(double T)
{
    return Command2D(CommandType::WAIT, CartesianCoordinates(0, T));
}

Command2D createChangeMarkSpeedCommand(double Speed)
{
    return Command2D(CommandType::CHANGESPEEDS, CartesianCoordinates(-1, Speed));
}

Command2D createChangeJumpSpeedCommand(double Speed)
{
    return Command2D(CommandType::CHANGESPEEDS, CartesianCoordinates(Speed, -1));
}

Command2D createChangeSpeedCommand(double JumpSpeed, double MarkSpeed)
{
    return Command2D(CommandType::CHANGESPEEDS, CartesianCoordinates(JumpSpeed, MarkSpeed));
}

Command2D createMarkCommand(double X, double Y)
{
    return createMarkCommand(CartesianCoordinates(X, Y));
}

Command2D createMarkCommand(const CartesianCoordinates& Target)
{
    return Command2D(CommandType::MARK, Target);
}

Command2D createJumpCommand(double X, double Y)
{
    return createJumpCommand(CartesianCoordinates(X, Y));
}

Command2D createJumpCommand(const CartesianCoordinates& Target)
{
    return Command2D(CommandType::JUMP, Target);
}

Command2D createCircleCommand(double CenterX, double CenterY)
{
    return createCircleCommand(CartesianCoordinates(CenterX, CenterY));
}

Command2D createCircleCommand(const CartesianCoordinates& Center)
{
    return Command2D(CommandType::CIRCLE, Center);
}

CommandListType createArcCommand(double MidX, double MidY, double X, double Y)
{
    return createArcCommand(CartesianCoordinates(MidX, MidY), CartesianCoordinates(X, Y));
}

CommandListType createArcCommand(const CartesianCoordinates& Mid, const CartesianCoordinates& Target)
{
    return CommandListType(
    {
        Command2D(CommandType::ARCMID, Mid),
        Command2D(CommandType::ARCTARGET, Target),
    });
}

CommandListType createSCANLABLogo(double ScalingFactor, const CartesianCoordinates& Center)
{
    CommandListType Logo;
    for (size_t I = 0; I < 8; ++I)
    {
        const double Factor = static_cast<double>(I);
        Logo.push_back(createJumpCommand(Center.X(), ScalingFactor + Center.Y()));
        Logo.push_back(createMarkCommand(-ScalingFactor*(1. - Factor / 7.) + Center.X(),
                                         -Factor / 7. * ScalingFactor + Center.Y()));
        Logo.push_back(createMarkCommand(ScalingFactor + Center.X(), Center.Y()));
    }
    return Logo;
}

CommandListType createCircle(double Radius, double StartingAngle, const CartesianCoordinates& Center)
{
    return CommandListType(
    {
        createJumpCommand(Center.X() + cos(StartingAngle) * Radius, Center.Y() + sin(StartingAngle) * Radius),
        createCircleCommand(Center),
    });
}

CommandListType createMultipleCircles(double OuterRadius, double MinRadius, double StepSize, double StartingAngle, const CartesianCoordinates& Center)
{
    CommandListType Circles;
    double Radius = OuterRadius;
    while (Radius >= MinRadius)
    {
        Circles.push_back(createJumpCommand(Center.X() + cos(StartingAngle) * Radius, Center.Y() + sin(StartingAngle) * Radius));
        Circles.push_back(createCircleCommand(Center));
        Radius -= StepSize;
    }
    return Circles;
}

CommandListType createDotArcs(double DotSize, double LaserSpotSize, const CartesianCoordinates& Center)
{
    CommandListType Spiral;
    const double Resolution = 0.01;
    const double Pitch = LaserSpotSize;

    double Radius = LaserSpotSize/4.;
    double NumberOfElements = 2 * PI * (Radius + Pitch) / Resolution;
    size_t NumberOfElementsCeil = static_cast<size_t>(std::ceil(NumberOfElements / 2.));
    CartesianCoordinates TempXY;

    Spiral.push_back(createJumpCommand(Center));
    Spiral.push_back(createJumpCommand(Center.X(), Center.Y() + Radius));

    while (Radius <= (DotSize - LaserSpotSize) / 2)
    {
        for (size_t j = 1; j <= NumberOfElementsCeil; j++)
        {
            Radius += 1. / NumberOfElementsCeil / 2. * Pitch;
            double Iterator = static_cast<double>(j);

            TempXY.X() = Center.X() + Radius * sin((Iterator - 0.5) / NumberOfElementsCeil * 2 * PI);
            TempXY.Y() = Center.Y() + Radius * cos((Iterator - 0.5) / NumberOfElementsCeil * 2 * PI);

            Radius += 1. / NumberOfElementsCeil / 2. * Pitch;

            appendCommandList(Spiral, createArcCommand(TempXY.X(), TempXY.Y(),
                                                       Center.X() + Radius * sin(Iterator / NumberOfElementsCeil * 2 * PI),
                                                       Center.Y() + Radius * cos(Iterator / NumberOfElementsCeil * 2 * PI))

                             );
        }
        NumberOfElements = 2. * PI * (Radius + Pitch) / Resolution;
        NumberOfElementsCeil = static_cast<size_t>(std::ceil(NumberOfElements / 2.));
    }
    Spiral.push_back(createCircleCommand(Center));

    return Spiral;
};

CommandListType createCross(double Crosslength, const CartesianCoordinates& Center)
{
    CommandListType Cross;
    Cross.push_back(createJumpCommand(Center.X() - Crosslength / 2, Center.Y()));
    Cross.push_back(createMarkCommand(Center.X() + Crosslength / 2, Center.Y()));
    Cross.push_back(createJumpCommand(Center.X(), Center.Y() - Crosslength / 2));
    Cross.push_back(createMarkCommand(Center.X(), Center.Y() + Crosslength / 2));
    return Cross;
};

CommandListType createLine(const CartesianCoordinates& Start, const CartesianCoordinates& End, bool ReverseDirection)
{
    CommandListType Line;
    CartesianCoordinates StartTmp = Start;
    CartesianCoordinates EndTmp = End;
    if (ReverseDirection)
    {
        StartTmp = End;
        EndTmp = Start;
    }
    Line.push_back(createJumpCommand(StartTmp));
    Line.push_back(createMarkCommand(EndTmp));
    return Line;
};


CommandListType createStageSkyWritingInX(const CartesianCoordinates& PrevPosition, const CartesianCoordinates& NextPosition, int Direction, bool& IsFirstOrLast, double Bandwidth, double VStage, double ScalingFactor, double PrevJumpSpeed, double MinWaitTime)
{
    CommandListType Turn;

    const double ca = 1;
    const double c = 0.86052; // Filter factor for T_inversion

    const double Tinversion = c / Bandwidth * ScalingFactor;
    const double LengthOfMotion = Tinversion / 2. * VStage / 2. * ca;
    const double TotalWaitTime = (Tinversion - (LengthOfMotion / VStage) - (IsFirstOrLast ? 0 : (abs(NextPosition.Y() - PrevPosition.Y()) / VStage)));
    const double WaitTime = 1. / 2. * (TotalWaitTime >= MinWaitTime ? TotalWaitTime : MinWaitTime);

    CartesianCoordinates WaitPosition1(PrevPosition.X() - Direction * LengthOfMotion, PrevPosition.Y());
    CartesianCoordinates WaitPosition2(NextPosition.X() - Direction * LengthOfMotion, NextPosition.Y());

    if (IsFirstOrLast)
    {
        Turn.push_back(createJumpCommand(PrevPosition.X(), WaitPosition2.Y()));
        Turn.push_back(createChangeJumpSpeedCommand(VStage));
        Turn.push_back(createJumpCommand(WaitPosition2));
        Turn.push_back(createWaitCommand(2 * WaitTime));
        Turn.push_back(createJumpCommand(NextPosition));
        Turn.push_back(createChangeJumpSpeedCommand(PrevJumpSpeed));
        IsFirstOrLast = false;
    }
    else
    {
        Turn.push_back(createJumpCommand(PrevPosition));
        Turn.push_back(createChangeJumpSpeedCommand(VStage));
        Turn.push_back(createJumpCommand(WaitPosition1));
        Turn.push_back(createWaitCommand(WaitTime));
        Turn.push_back(createJumpCommand(WaitPosition2));
        Turn.push_back(createWaitCommand(WaitTime));
        Turn.push_back(createJumpCommand(NextPosition));
        Turn.push_back(createChangeJumpSpeedCommand(PrevJumpSpeed));
    }
    return Turn;
}

CommandListType createStageSkyWritingInY(const CartesianCoordinates& PrevPosition, const CartesianCoordinates& NextPosition, int Direction, bool& IsFirstOrLast, double Bandwidth, double VStage, double ScalingFactor, double PrevJumpSpeed, double MinWaitTime)
{
    CommandListType Turn;

    const double ca = 1;
    const double c = 0.86052; // Filter factor for T_inversion

    double Tinversion = c / Bandwidth * ScalingFactor;
    double LengthOfMotion = Tinversion / 2. * VStage / 2. * ca;
    double TotalWaitTime = (Tinversion - (LengthOfMotion / VStage) - (IsFirstOrLast ? 0 : (abs(NextPosition.X() - PrevPosition.X()) / VStage)));
    const double WaitTime = 1. / 2. * (TotalWaitTime >= MinWaitTime ? TotalWaitTime : MinWaitTime);

    CartesianCoordinates WaitPosition1(PrevPosition.X(), PrevPosition.Y() + Direction * LengthOfMotion);
    CartesianCoordinates WaitPosition2(NextPosition.X(), NextPosition.Y() + Direction * LengthOfMotion);

    if (IsFirstOrLast)
    {
        Turn.push_back(createJumpCommand(WaitPosition2.X(), PrevPosition.Y()));
        Turn.push_back(createChangeJumpSpeedCommand(VStage));
        Turn.push_back(createJumpCommand(WaitPosition2));
        Turn.push_back(createWaitCommand(2 * WaitTime));
        Turn.push_back(createJumpCommand(NextPosition));
        Turn.push_back(createChangeJumpSpeedCommand(PrevJumpSpeed));

        IsFirstOrLast = false;
    }
    else
    {
        Turn.push_back(createJumpCommand(PrevPosition));
        Turn.push_back(createChangeJumpSpeedCommand(VStage));
        Turn.push_back(createJumpCommand(WaitPosition1));
        Turn.push_back(createWaitCommand(WaitTime));
        Turn.push_back(createJumpCommand(WaitPosition2));
        Turn.push_back(createWaitCommand(WaitTime));
        Turn.push_back(createJumpCommand(NextPosition));
        Turn.push_back(createChangeJumpSpeedCommand(PrevJumpSpeed));
    }

    return Turn;
}

CommandListType createGrid(const CartesianCoordinates& Start, const CartesianCoordinates& End, const CartesianCoordinates& StepSize, bool XDirection, bool RemoveLastSymbol, double FoV, std::function<CommandListType(CartesianCoordinates, int, int, double)> MarkingFigure)
{
    CartesianCoordinates Position = Start;
    int Direction = 1;
    CommandListType GridPattern;
    size_t LastSymbolLength = 0;
    int BiDirectionality = 1;
    double CutOff = -1;

    if (XDirection)
    {
        while (((Position.Y() >= Start.Y() - EPSILON) && (Position.Y() <= End.Y() + EPSILON))
               ||
               ((Position.Y() <= Start.Y() + EPSILON) && (Position.Y() >= End.Y() - EPSILON)))
        {
            BiDirectionality = 1;
            changeDirection(Direction, Position.X(), Start.X(), End.X());

            if ((Position.Y() + FoV - End.Y()) > EPSILON)
            {
                CutOff = End.Y() - Position.Y();
            }

            while (((Position.X() >= Start.X() - EPSILON) && (Position.X() <= End.X() + EPSILON))
                   ||
                   ((Position.X() <= Start.X() + EPSILON) && (Position.X() >= End.X() - EPSILON)))
            {
                const CommandListType Symbol = MarkingFigure(Position, Direction, BiDirectionality, CutOff);
                LastSymbolLength = Symbol.size();
                appendCommandList(GridPattern, Symbol);
                Position.X() += Direction*StepSize.X();
                BiDirectionality *= -1;
            }
            Position.Y() += StepSize.Y();
        }
    }
    else
    {
        while (((Position.X() >= Start.X() - EPSILON) && (Position.X() <= End.X() + EPSILON))
               ||
               ((Position.X() <= Start.X() + EPSILON) && (Position.X() >= End.X() - EPSILON)))
        {
            BiDirectionality = 1;
            changeDirection(Direction, Position.Y(), Start.Y(), End.Y());

            if ((Position.X() + FoV - End.X()) > EPSILON)
            {
                CutOff = End.X() - Position.X();
            }
            while (((Position.Y() >= Start.Y() - EPSILON) && (Position.Y() <= End.Y() + EPSILON))
                   ||
                   ((Position.Y() <= Start.Y() + EPSILON) && (Position.Y() >= End.Y() - EPSILON)))
            {
                const CommandListType Symbol = MarkingFigure(Position, Direction, BiDirectionality, CutOff);
                LastSymbolLength = Symbol.size();
                appendCommandList(GridPattern, Symbol);
                Position.Y() += Direction*StepSize.Y();
                BiDirectionality *= -1;
            }
            Position.X() += StepSize.X();
        }
    }
    if (RemoveLastSymbol)
    {
        GridPattern.erase(GridPattern.end() - (LastSymbolLength), GridPattern.end());
    }
    return GridPattern;
}

CommandListType createGridWithStageSkyWriting(const CartesianCoordinates& Start, const CartesianCoordinates& End, const CartesianCoordinates& StepSize, bool XDirection, double FoV, double Bandwidth, double VStage, double ScalingFactor, double PrevJumpSpeed, double MinWaitTime, std::function<CommandListType(CartesianCoordinates, int, int, double)> MarkingFigure)
{
    CartesianCoordinates Position = Start;
    int Direction = 1;
    bool IsFirstOrLast = true;
    int BiDirectionality = 1;
    double CutOff = -1;

    CommandListType GridPattern;

    double CutOffStepSize = CutOff;

    if (XDirection)
    {
        while (((Position.Y() >= Start.Y() - EPSILON) && (Position.Y() <= End.Y() + EPSILON))
               ||
               ((Position.Y() <= Start.Y() + EPSILON) && (Position.Y() >= End.Y() - EPSILON)))
        {
            changeDirection(Direction, Position.X(), Start.X(), End.X());
            BiDirectionality = 1;
            if ((Position.Y() + FoV - End.Y()) > EPSILON)
            {
                CutOff = End.Y() - Position.Y();
            }
            CutOffStepSize = (CutOff > -EPSILON) ? CutOff : (StepSize.Y() - StepSize.X());
            appendCommandList(GridPattern,
                              createStageSkyWritingInX(CartesianCoordinates(Position.X(), Position.Y() - (StepSize.Y() + StepSize.X()) / 2),
                                                       CartesianCoordinates(Position.X(), Position.Y() + CutOffStepSize / 2), Direction,
                                                       IsFirstOrLast, Bandwidth,
                                                       VStage, ScalingFactor,
                                                       PrevJumpSpeed, MinWaitTime));
            while (((Position.X() >= Start.X() - EPSILON) && (Position.X() <= End.X() + EPSILON))
                   ||
                   ((Position.X() <= Start.X() + EPSILON) && (Position.X() >= End.X() - EPSILON)))
            {
                appendCommandList(GridPattern, MarkingFigure(Position, Direction, BiDirectionality, CutOff));
                Position.X() += Direction*StepSize.X();
                BiDirectionality *= -1;
            }
            Position.Y() += StepSize.Y();
        }
        Position.Y() -= StepSize.Y();
        IsFirstOrLast = true;
        changeDirection(Direction, Position.X(), Start.X(), End.X());
        CutOffStepSize = (CutOff > -EPSILON) ? CutOff : (StepSize.Y() - StepSize.X());
        appendCommandList(GridPattern, createStageSkyWritingInX(CartesianCoordinates(Position.X(), Position.Y() - (CutOff > -EPSILON ? CutOff : (StepSize.Y() - StepSize.X())) / 2),
                                                                CartesianCoordinates(Position.X(), Position.Y() + CutOffStepSize / 2),
                                                                Direction, IsFirstOrLast, Bandwidth, VStage, ScalingFactor, PrevJumpSpeed, MinWaitTime));
    }
    else
    {
        while (((Position.X() >= Start.X() - EPSILON) && (Position.X() <= End.X() + EPSILON))
               ||
               ((Position.X() <= Start.X() + EPSILON) && (Position.X() >= End.X() - EPSILON)))
        {
            changeDirection(Direction, Position.Y(), Start.Y(), End.Y());
            BiDirectionality = 1;
            if ((Position.X() + FoV - End.X()) > EPSILON)
            {
                CutOff = End.X() - Position.X();
            }
            CutOffStepSize = (CutOff > -EPSILON) ? CutOff : (StepSize.X() - StepSize.Y());
            appendCommandList(GridPattern,
                              createStageSkyWritingInY(CartesianCoordinates(Position.X() - (StepSize.Y() + StepSize.X()) / 2, Position.Y()),
                                                       CartesianCoordinates(Position.X() + CutOffStepSize / 2, Position.Y()), Direction,
                                                       IsFirstOrLast, Bandwidth,
                                                       VStage, ScalingFactor,
                                                       PrevJumpSpeed, MinWaitTime));
            BiDirectionality = 1;

            while (((Position.Y() >= Start.Y() - EPSILON) && (Position.Y() <= End.Y() + EPSILON))
                   ||
                   ((Position.Y() <= Start.Y() + EPSILON) && (Position.Y() >= End.Y() - EPSILON)))
            {
                const CommandListType Symbol = MarkingFigure(Position, Direction, BiDirectionality, CutOff);
                appendCommandList(GridPattern, Symbol);
                Position.Y() += Direction*StepSize.Y();
                BiDirectionality *= -1;
            }
            Position.X() += StepSize.X();
        }
        IsFirstOrLast = true;
        changeDirection(Direction, Position.Y(), Start.Y(), End.Y());
        CutOffStepSize = (CutOff > -EPSILON) ? CutOff : (StepSize.X() - StepSize.Y());
        appendCommandList(GridPattern,
                          createStageSkyWritingInY(CartesianCoordinates(Position.X() - (CutOff > -EPSILON ? CutOff : (StepSize.Y() - StepSize.X())) / 2, Position.Y()),
                                                   CartesianCoordinates(Position.X() + CutOffStepSize / 2, Position.Y()),
                                                   Direction, IsFirstOrLast, Bandwidth, VStage, ScalingFactor, PrevJumpSpeed, MinWaitTime));
    }

    return GridPattern;
}

void changeDirection(int& Direction, double& Position, double Start, double End)
{
    if (Direction == 1)
    {
        Position = End;
        Direction = -1;
    }
    else if (Direction == -1)
    {
        Position = Start;
        Direction = 1;
    }
    return;
}
