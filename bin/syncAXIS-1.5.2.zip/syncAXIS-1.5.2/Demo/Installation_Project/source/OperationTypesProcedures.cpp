/*
***************************************************************************
File: OperationTypesProcedures.cpp

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#include "Jobs.h"
#include "syncAXISControl.h"
#include "DemoFunctions.h"
#include "ConfigFileSearch.h"
#include "IncludePath.h"

#include <cmath>
#include <future>
#include <conio.h>

uint32_t initialize(size_t& SLHandle, const CartesianCoordinates& Offset)
{
    std::string ExeDir = "";
    std::vector<std::string> ConfigFileNamesExeDir = readConfigFileNamesInExeDir(ExeDir);

    std::string FileName = "";
    if (AdditionalConfigFileDir != "")
    {
        const std::string AddDir = AdditionalConfigFileDir;
        std::vector<std::string> ConfigFilePaths;
        for (auto Name : ConfigFileNamesExeDir)
        {
            ConfigFilePaths.push_back(ExeDir + "\\" + Name);
        }
        std::vector<std::string> ConfigFileNamesAddDir = readConfigFileNames(AddDir);
        for (auto Name : ConfigFileNamesAddDir)
        {
            ConfigFilePaths.push_back(AddDir + "/" + Name);
        }
        if (ConfigFilePaths.empty())
        {
            std::cout << "No config files are found!" << std::endl;
            std::cout << "Neither in execution directory " + ExeDir << "," << std::endl;
            std::cout << "nor in specified directory " + AddDir << "." << std::endl;
            return false;
        }
        size_t ConfigFileIndex = readConfigFileIndex(ConfigFilePaths);
        FileName = ConfigFilePaths[ConfigFileIndex - 1];
    }
    else
    {
        if (ConfigFileNamesExeDir.empty())
        {
            std::cout << "No config files are found in the execution directory " + ExeDir + "." << std::endl;
            return false;
        }
        size_t ConfigFileIndex = readConfigFileIndex(ConfigFileNamesExeDir);
        FileName = ExeDir + "\\" + ConfigFileNamesExeDir[ConfigFileIndex - 1].c_str();
    }

    uint32_t RetVal = initializeControl(SLHandle, FileName);
    if (RetVal == 0)
    {
        std::cout << "Instance " << SLHandle << " successfully created!" << std::endl;
        applyTransformation(SLHandle, RetVal, Offset);
    }
    else
    {
        std::cout << "Creating instance " << SLHandle << " failed! Please check for errors and delete instance " << SLHandle << "." << std::endl;
    }

    return RetVal;
}

uint32_t checkLaserFiring(size_t SLHandle)
{
    uint32_t RetVal = setToManualPositioningMode(SLHandle);

    std::cout << "CAUTION! During this test, the laser will be fired. Please make sure to be prepared!" << std::endl;
    std::cout << "Do you want to activate the laser? (y/n) \nPlease enter:";

    while (tryReadingBool())
    {

        RetVal |= laserOn(SLHandle);
        std::cout << "Press any key to deactivate the laser...";
        while (!_kbhit())
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        if (_kbhit()) { _getch(); }

        RetVal |= laserOff(SLHandle);

        std::cout << std::endl << "Do you want to activate the laser? (y/n) \nPlease enter:";
    }

    RetVal |= setTosyncAXISMode(SLHandle);

    return RetVal;
}

uint32_t referenceRun(size_t SLHandle)
{
    uint32_t RetVal = 0;
    std::cout << "CAUTION! During this reference run, the laser will be fired to make the scanner motion visible. Please make sure to be prepared!";
    std::cout << "The stage will be moved! Keep clear of the stage!\nPlease enter the stage speed: ";
    const double StageSpeed = tryReadingDouble(expectPositiveDouble);
    std::cout << "Please enter the stage's motion range: ";
    const double StageWidth = tryReadingDouble(expectPositiveDouble);

    const double ScannerWidth = 10;

    std::cout << "Do you want to start the job execution? The stage might move and laser might be fired! (y/n):";
    if (tryReadingBool())
    {
        RetVal |= executeReferenceRun(SLHandle, ScannerWidth, StageWidth, StageSpeed);
    }
    else
    {
        std::cout << "Aborted by user input! Please try again!" << std::endl << std::endl;
    }

    return RetVal;
}

uint32_t testMarking(size_t SLHandle)
{
    double ScalingFactor = readScalingFactor();
    return executeTestMarking(SLHandle, ScalingFactor);
}

uint32_t scannerCalibration(size_t SLHandle)
{
    uint32_t RetVal = 0;
    double GridSize;
    int NumberOfGridPoints;
    std::cout << "Specify the size of the calibration grid in [mm]." << std::endl <<
              "The grid should fit in the scanner field of view." << std::endl <<
              "Please enter: ";
    GridSize = tryReadingDouble(expectPositiveDouble);
    std::cout << "Marking a grid of n x n objects." << std::endl <<
              "Please specify n: ";
    NumberOfGridPoints = tryReadingInt(expectOddIntGreater1);
    std::cout << "\nPlease enter the stage speed :";
    double StageSpeed = tryReadingDouble(expectPositiveDouble);
    std::cout << std::endl << std::endl;

    RetVal |= executeScannerCalibrationJob(SLHandle, GridSize, NumberOfGridPoints, StageSpeed);
    return RetVal;
}

uint32_t stageCalibration(size_t SLHandle)
{
    uint32_t RetVal = 0;
    double GridSize;
    int NumberOfGridPoints;
    std::cout << "Specify the size of the error mapping grid in [mm]: ";
    GridSize = tryReadingDouble(expectPositiveDouble);
    std::cout << "Marking a grid of n x n objects." << std::endl <<
              "Please specify n: ";
    NumberOfGridPoints = tryReadingInt(expectOddIntGreater1);
    std::cout << "\nPlease enter the stage speed :";
    double StageSpeed = tryReadingDouble(expectPositiveDouble);
    std::cout << std::endl << std::endl;

    RetVal |= executeStageCalibrationJob(SLHandle, GridSize, NumberOfGridPoints, StageSpeed);
    return RetVal;
}

uint32_t combinedAccuracy(size_t SLHandle)
{
    uint32_t RetVal = 0;
    double GridSize;
    int NumberOfGridPoints;
    double FoV;
    std::cout << "Specify the gridsize of the test job for determining the accuracy of combined motion in [mm]." << std::endl <<
              "Nearly stage range (a little less due to the width of the grid objects and stage turnaround distance) is recommended." << std::endl <<
              "Please enter: ";
    GridSize = tryReadingDouble(expectPositiveDouble);
    std::cout << "Marking a grid of n x n objects." << std::endl <<
              "Please specify n: ";
    NumberOfGridPoints = tryReadingInt(expectOddIntGreater1);
    std::cout << std::endl << "Specify the scanner field of view you want to use in [mm]." << std::endl <<
              "Please enter: ";
    FoV = tryReadingDouble(expectPositiveDouble);
    std::cout << std::endl << std::endl;

    bool UseStageSkyWriting = false;
    double Bandwidth = 0;
    double vStage = 0;
    double ScalingFactor = 1;

    Geometries GeometryCase = readGeometry();

    std::cout << "Do you want to include a turnaround motion for the stage? (y/n):";
    if (tryReadingBool())
    {
        std::cout << "Please enter the approximate stage speed during the line of marking (can be seen in simulation) in mm/s:";
        vStage = tryReadingDouble(expectPositiveDouble);

        std::cout << "Please enter the filter bandwidth being used (see syncAXISConfig.xml):";
        Bandwidth = tryReadingDouble(expectPositiveDouble);

        std::cout << "Please enter a scaling factor for the time and distance of the turnaround motion (0-1):";
        ScalingFactor = tryReadingDouble(expectDoubleBetween0And1);

        UseStageSkyWriting = true;
    }

    return executeCombinedAccuracyJob(SLHandle, GridSize, NumberOfGridPoints, FoV, GeometryCase, UseStageSkyWriting, vStage, Bandwidth, ScalingFactor);
}

uint32_t checkLaserDelays(size_t SLHandle, CartesianCoordinates Offset)
{
    uint32_t RetVal = 0;
    std::cout << "A grid of objects with different LaserDelays will be marked. PreTriggerTime will be varied in y direction while LaserSwitchOffset will be varied in x direction." << std::endl << std::endl;
    std::cout << "Please enter the maximum speed of your scan system in [mm/s]:";
    double vScanner = tryReadingDouble(expectPositiveDouble);

    std::cout << "Please enter a start value for LaserSwitchOffset in [us]: (Recommended for first try: -40)";
    double StartSwitchOffset = tryReadingDouble(expectAnyDouble);

    std::cout << "11 iterations will be executed.\nPlease enter an increment value for LaserSwitchOffset in [us]: (Recommended for first try: 5)";
    double IncrementSwitchOffset = tryReadingDouble(expectPositiveDouble);

    std::cout << "Please enter a start value for LaserPreTriggerTime in [us]: (Recommended for first try: -10)";
    double StartPreTrigger = tryReadingDouble(expectAnyDouble);

    std::cout << "11 iterations will be executed.\nPlease enter a increment value for LaserPreTriggerTime in [us]: (Recommended for first try: 2)";
    double IncrementPreTrigger = tryReadingDouble(expectPositiveDouble);

    std::cout << std::endl << std::endl;

    RetVal |= executeLaserDelayCheck(SLHandle, vScanner, StartSwitchOffset, IncrementSwitchOffset, StartPreTrigger, IncrementPreTrigger, Offset);
    return RetVal;
}

uint32_t checkCalibrations(size_t SLHandle)
{
    uint32_t RetVal = 0;
    double GridSize; // Should fit in FoV
    int NumberOfGridPoints;
    std::cout << "Specify the size of the calibration grid in [mm]." << std::endl <<
              "The grid should fit in the scanner field of view." << std::endl <<
              "Please enter: ";
    GridSize = tryReadingDouble(expectPositiveDouble);
    std::cout << "Marking a grid of n x n objects." << std::endl <<
              "Please specify n: ";
    NumberOfGridPoints = tryReadingInt(expectOddIntGreater1);

    std::cout << "\nPlease enter the stage speed: ";
    double StageSpeed = tryReadingDouble(expectPositiveDouble);

    std::cout << "The stage will be moved! Keep clear of the stage!";

    std::cout << std::endl << std::endl;

    RetVal |= executeCalibrationCheck(SLHandle, GridSize, NumberOfGridPoints, StageSpeed);
    return RetVal;
}

uint32_t checkSystemDelays(size_t SLHandle, const CartesianCoordinates& Offset)
{
    uint32_t RetVal = 0;
    std::cout << "Two sets of lines will be marked with high stage velocity. The lines are marked perpendicular to the stage's motion direction.\n" <<
              "If the positions of the lines do not match in stage motion direction, please contact SCANLAB. The test is repeated in 4 directions." << std::endl << std::endl;
    std::cout << "Please enter the maximal speed of your stage in [mm/s]:";
    double vStage = tryReadingDouble(expectPositiveDouble);
    std::cout << "Please enter the stage's motion range in [mm] (+/-):";
    double rStage = tryReadingDouble(expectPositiveDouble);
    std::cout << std::endl << std::endl;
    RetVal |= executeSystemDelayCheck(SLHandle, vStage, rStage, Offset);
    applyTransformation(SLHandle, RetVal, Offset);
    return RetVal;
}

uint32_t changeSettingsMenu(size_t SLHandle,
                            CartesianCoordinates& Offset,
                            CartesianCoordinates& PrevOffset)
{
    uint32_t RetVal = 0;
    bool Repeat = true;

    while (Repeat)
    {
        std::string InputString;
        printOptions(getChangeSettingCaseDescriptions());
        std::cin >> InputString;

        if (getChangeSettingCases().count(InputString) > 0)
        {
            const SettingsType Case = getChangeSettingCases(InputString);
            std::cout << "You chose case " << InputString << " (" << getChangeSettingCaseDescriptions(Case).Brief << ") -> \""
                      << getChangeSettingCaseDescriptions(Case).Description << "\"" << std::endl << std::endl;
            printSeparationLine();

            switch (Case)
            {
                case SettingsType::EXIT:
                {
                    Repeat = false;
                    break;
                }
                case SettingsType::OPMODE:
                {
                    if (RetVal == 0)
                    {
                        RetVal |= changeOperationMode(SLHandle, Offset, PrevOffset);
                    }
                    break;
                }
                case SettingsType::SPEEDS:
                {
                    if (RetVal == 0)
                    {
                        RetVal |= changeSpeed(SLHandle);
                    }
                    break;
                }
                case SettingsType::OFFSET:
                {
                    std::cout << "Please enter a new offset in x direction in [mm]: ";
                    Offset.X() = tryReadingDouble(expectAnyDouble);
                    std::cout << "Please enter a new offset in y direction in [mm]: ";
                    Offset.Y() = tryReadingDouble(expectAnyDouble);
                    std::cout << std::endl << std::endl << "The new offset is (" << Offset.X() << ", " << Offset.Y() << ")." << std::endl <<
                              "Please note that this offset is kept until this setting is changed again." << std::endl <<
                              "Reinitializing and deleting will not affect the offset." << std::endl;

                    applyTransformation(SLHandle, RetVal, Offset);
                    break;
                }
            }
            std::cout << std::endl << std::endl << "Case " << InputString << " (" << getChangeSettingCaseDescriptions(Case).Brief << ") finished with return value: " << RetVal << "." << std::endl << std::endl;
            printSeparationLine();
        }
        else
        {
            printSeparationLine();
            std::cout << std::endl << "Invalid input parameter, please try again." << std::endl << std::endl;
            printSeparationLine();
        }
    }
    return RetVal;
};

uint32_t deleteInstance(size_t& SLHandle)
{
    if (SLHandle == 0)
    {
        std::cout << "Initialize first." << std::endl;
        return false;
    }
    return deleteControl(SLHandle);
}
