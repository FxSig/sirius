/*
***************************************************************************
File: syncAXISControl.cpp

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/

#include "DemoFunctions.h"
#include "syncAXISControl.h"

#include "syncAXIS.h"

#include <thread>
#include <cmath>

constexpr double PI = Constants::PI;
constexpr double EPSILON = Constants::EPSILON;

uint32_t initializeControl(size_t& SLHandle, const std::string& ConfigFile)
{
    uint32_t RetVal = 0;
    if (SLHandle != 0)
    {
        RetVal = slsc_cfg_reinitialize_from_file(SLHandle, ConfigFile.c_str());
    }
    else
    {
        RetVal = slsc_cfg_initialize_from_file(&SLHandle, ConfigFile.c_str());
    }
    if (0 == RetVal)
    {
        // Use automatic list handling mode for this project
        RetVal |= slsc_cfg_set_list_handling_mode(SLHandle, slsc_ListHandlingMode::slsc_ListHandlingMode_RepeatWhileBufferFull, nullptr);
    }
    return RetVal;
}

uint32_t deleteControl(size_t& SLHandle)
{
    uint32_t RetVal = slsc_cfg_delete(SLHandle);
    SLHandle = 0;
    return RetVal;
}

uint32_t initializeCopy(size_t OrigHandle, size_t& CopyHandle)
{
    return slsc_cfg_initialize_copy(&CopyHandle, OrigHandle);
}

uint32_t applyTransformation(size_t SLHandle, const TransformationMatrix& Transformation, const CartesianCoordinates& Offset)
{
    return slsc_cfg_set_matrix_and_offset(SLHandle, Transformation.data(), Offset.data());
}

uint32_t applyTransformation(size_t SLHandle, double Rotation, const CartesianCoordinates& Offset)
{
    return slsc_cfg_set_rot_and_offset_2d(SLHandle, Rotation * Constants::TO_RAD, Offset.data());
}

uint32_t applyTransformation(size_t SLHandle, const CartesianCoordinates& Offset)
{
    return applyTransformation(SLHandle, 0.0, Offset);
}

uint32_t setMode(size_t SLHandle, slsc_OperationMode Mode)
{
    slsc_OperationMode CurrentMode;
    uint32_t RetVal = getMode(SLHandle, CurrentMode);
    if (CurrentMode != Mode)
    {
        return slsc_cfg_set_mode(SLHandle, Mode);
    }
    return RetVal;
}

uint32_t getMode(size_t SLHandle, slsc_OperationMode& Mode)
{
    return slsc_cfg_get_mode(SLHandle, &Mode);
}

uint32_t getErrors(size_t SLHandle, std::vector<std::pair<uint64_t, std::string>>& Errors)
{
    size_t ErrorCount = 0;
    uint32_t RetVal = slsc_ctrl_get_error_count(SLHandle, &ErrorCount);
    Errors.clear();
    for (size_t Counter = 0; Counter < ErrorCount; ++Counter)
    {
        uint64_t ErrorCode = 0;
        const size_t ErrorTextSize = 1000;
        std::array<char, ErrorTextSize> ErrorText;
        RetVal |= slsc_ctrl_get_error(SLHandle, Counter, &ErrorCode, ErrorText.data(), ErrorTextSize);
        std::pair<uint64_t, std::string> Pair(ErrorCode, ErrorText.data());
        Errors.push_back(Pair);
    }
    return RetVal;
}

uint32_t cfgSetJumpSpeed(size_t SLHandle, double Speed)
{
    return slsc_cfg_set_jump_speed(SLHandle, Speed);
}

uint32_t cfgSetMarkSpeed(size_t SLHandle, double Speed)
{
    return slsc_cfg_set_mark_speed(SLHandle, Speed);
}

uint32_t getTrajectoryConfig(size_t SLHandle, TrajectoryConfiguration& TrajConfig)
{
    TrajConfig.CreatedBySyncAxisDll = true;
    return slsc_cfg_get_trajectory_config(SLHandle, &TrajConfig.Content);
}

uint32_t setTrajectoryConfig(size_t SLHandle, const TrajectoryConfiguration& Config)
{
    return slsc_cfg_set_trajectory_config(SLHandle, Config.Content);
}

uint32_t writeJob(size_t SLHandle, size_t& JobID, const CommandListType& MarkingPattern)
{
    uint32_t RetVal = 0;
    RetVal |= slsc_list_begin(SLHandle, &JobID);
    RetVal |= writeCommandList(SLHandle, MarkingPattern);
    RetVal |= slsc_list_end(SLHandle);
    return RetVal;
}

uint32_t writeModule(size_t SLHandle, size_t& JobID, const CartesianCoordinates& Center, const CommandListType& MarkingPattern, const char* ModuleName)
{
    uint32_t RetVal = 0;
    RetVal |= slsc_list_begin_module(SLHandle, &JobID, Center.data(), ModuleName);
    RetVal |= writeCommandList(SLHandle, MarkingPattern);
    RetVal |= slsc_list_end(SLHandle);
    return RetVal;
}

uint32_t writeCommandList(size_t SLHandle, const CommandListType& MarkingPattern)
{
    uint32_t RetVal = 0;
    for (size_t i = 0; i < MarkingPattern.size(); i++)
    {
        switch (MarkingPattern[i].Type)
        {
            case CommandType::JUMP:
            {
                // Writes a list command to jump to the indicated position.
                RetVal |= slsc_list_jump_abs(SLHandle, MarkingPattern[i].Target.data());
                break;
            }
            case CommandType::MARK:
            {
                // Writes a list command to mark a vector from the recent to the indicated position.
                RetVal |= slsc_list_mark_abs(SLHandle, MarkingPattern[i].Target.data());
                break;
            }
            case CommandType::CIRCLE:
            {
                // Writes a list command to mark a circle around the indicated position starting from the recent position.
                RetVal |= slsc_list_circle_2d_abs(SLHandle, MarkingPattern[i].Target.data(), 2 * PI);
                break;
            }
            case CommandType::ARCMID:
            {
                if (MarkingPattern[i + 1].Type == CommandType::ARCTARGET)
                {
                    RetVal |= slsc_list_arc_abs(SLHandle, MarkingPattern[i].Target.data(), MarkingPattern[i + 1].Target.data());
                }
                break;
            }
            case CommandType::CHANGESPEEDS:
            {
                // Change mark and or jump speed inside of a list. The X value represents the jump speed while the Y value represents mark speed.
                if (MarkingPattern[i].Target.X() > EPSILON)
                {
                    RetVal |= slsc_list_set_jump_speed(SLHandle, MarkingPattern[i].Target.X());
                }
                if (MarkingPattern[i].Target.Y() > EPSILON)
                {
                    RetVal |= slsc_list_set_mark_speed(SLHandle, MarkingPattern[i].Target.Y());
                }
                break;
            }
            case CommandType::WAIT:
            {
                if (MarkingPattern[i].Target.X() > EPSILON)
                {
                    RetVal |= slsc_list_wait_with_laser_on(SLHandle, std::ceil((MarkingPattern[i].Target.X() - EPSILON) / (1e-5))*(1e-5));  // Only multiples of 10us allowed
                }
                if (MarkingPattern[i].Target.Y() > EPSILON)
                {
                    RetVal |= slsc_list_wait_with_laser_off(SLHandle, std::ceil((MarkingPattern[i].Target.Y() -EPSILON) / (1e-5))*(1e-5));  // Only multiples of 10us allowed
                }
                break;
            }
            case CommandType::ARCTARGET: //skipped, see ARCMID
            default:
                break;
        }
        if (RetVal != 0)
        {
            break;
        }
    }

    if (RetVal != 0)
    {
        std::cout << "Error occurred during list writing: " << RetVal << std::endl;
    }
    return RetVal;
}


uint32_t writeJobOnModuleList(size_t SLHandle, size_t& JobID, const std::vector<CartesianCoordinates> PositionList,  const char* ModuleName)
{
    uint32_t RetVal = 0;
    CartesianCoordinates Center;
    RetVal |= slsc_list_begin(SLHandle, &JobID);
    for (auto Position : PositionList)
    {
        RetVal |= slsc_list_set_rot_and_offset_2d(SLHandle, 0.0, Position.data());
        RetVal |= slsc_list_playback_module(SLHandle, ModuleName);
        RetVal |= slsc_list_set_rot_and_offset_2d(SLHandle, 0.0, Center.data());
    }
    RetVal |= slsc_list_end(SLHandle);
    return RetVal;
}


uint32_t startJob(size_t SLHandle)
{
    bool JobStart = false;
    return startJob(SLHandle, JobStart);
}

uint32_t startJob(size_t SLHandle, bool& AutoStart)
{
    slsc_ExecState State = slsc_ExecState_Idle;
    uint32_t RetVal = 0;
    while (State != slsc_ExecState_ReadyForExecution)
    {
        RetVal |= slsc_ctrl_get_exec_state(SLHandle, &State);
        if (State == slsc_ExecState_NotInitOrError || 0 != RetVal)
        {
            std::cout << "An error has happend!" << std::endl;
            return RetVal;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }

    if (!AutoStart)
    {
        std::cout << "Do you want to start the job execution? (the stage might move and laser might be fired!) (y/n):";
        AutoStart = tryReadingBool();
    }

    if (AutoStart)
    {
        std::cout << "Start Execution" << std::endl;
        RetVal |= slsc_ctrl_start_execution(SLHandle);
        std::this_thread::sleep_for(std::chrono::milliseconds(10));

        while (State != slsc_ExecState_Idle)
        {
            RetVal |= slsc_ctrl_get_exec_state(SLHandle, &State);
            if (State == slsc_ExecState_NotInitOrError || 0 != RetVal)
            {
                std::cout << "An error has happend!" << std::endl;
                return RetVal;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
        std::cout << "Execution finished!" << std::endl;
    }
    else
    {
        AutoStart = false;
        std::cout << "Aborted! Please delete and initialize again!" << std::endl << std::endl;
        RetVal |= slsc_ctrl_stop(SLHandle);
    }

    return RetVal;
}

uint32_t getJobCharacteristic(size_t SLHandle, std::map<slsc_JobCharacteristic, std::pair<std::string, double>>& JobChars, size_t JobID)
{
    std::map<slsc_JobCharacteristic, std::pair<std::string, double>> JobCharMap
    {
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerPosX, { "ScannerPosX", 0.0}},
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerPosY, { "ScannerPosY", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StagePosX,   { "StagePosX",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StagePosY,   { "StagePosY",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerVelX, { "ScannerVelX", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerVelY, { "ScannerVelY", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StageVelX, { "StageVelX", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StageVelY, { "StageVelY", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerAccX, { "ScannerAccX", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerAccY, { "ScannerAccY", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StageAccX, { "StageAccX", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StageAccY, { "StageAccY", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StageJerkX, { "StageJerkX", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StageJerkY, { "StageJerkY", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerPosXLaserOn,{ "ScannerPosXLaserOn", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerPosYLaserOn,{ "ScannerPosYLaserOn", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StagePosXLaserOn,{ "StagePosXLaserOn", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StagePosYLaserOn,{ "StagePosYLaserOn", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_MotionMicroSteps, { "MotionMicroSteps", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_MinimalMarkSpeed, { "MinimalMarkSpeed", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_MaximalMarkSpeed,{ "MaximalMarkSpeed", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_InsertedSkywritings,{ "InsertedSkywritings", 0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerPosXmax,{ "ScannerPosXmax",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerPosXmin,{ "ScannerPosXmin",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerPosYmax,{ "ScannerPosYmax",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerPosYmin,{ "ScannerPosYmin",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerPosXmaxLaserOn,{ "ScannerPosXmaxLaserOn",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerPosXminLaserOn,{ "ScannerPosXminLaserOn",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerPosYmaxLaserOn,{ "ScannerPosYmaxLaserOn",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerPosYminLaserOn,{ "ScannerPosYminLaserOn",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StagePosXmax,{ "StagePosXmax",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StagePosXmin,{ "StagePosXmin",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StagePosYmax,{ "StagePosYmax",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StagePosYmin,{ "StagePosYmin",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StagePosXmaxLaserOn,{ "StagePosXmaxLaserOn",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StagePosXminLaserOn,{ "StagePosXminLaserOn",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StagePosYmaxLaserOn,{ "StagePosYmaxLaserOn",   0.0 } },
        { slsc_JobCharacteristic::slsc_JobCharacteristic_StagePosYminLaserOn,{ "StagePosYminLaserOn",   0.0 } },
    };

    uint32_t RetVal = 0;
    for (auto& Element : JobCharMap)
    {
        RetVal |= slsc_ctrl_get_job_characteristic(SLHandle, JobID, Element.first, &Element.second.second);
        if (RetVal != 0)
        {
            break;
        }
    }
    JobChars = std::move(JobCharMap);
    return RetVal;
}

uint32_t laserOn(size_t SLHandle)
{
    return slsc_ctrl_laser_signal_on(SLHandle);
}

uint32_t laserOff(size_t SLHandle)
{
    return slsc_ctrl_laser_signal_off(SLHandle);
}

uint32_t setToManualPositioningMode(size_t SLHandle)
{
    return slsc_ctrl_unfollow(SLHandle);
}

uint32_t setTosyncAXISMode(size_t SLHandle)
{
    return slsc_ctrl_follow(SLHandle);
}

uint32_t moveStage(size_t SLHandle, const CartesianCoordinates& Target, double Speed)
{
    return slsc_ctrl_move_stage_abs(SLHandle, Target.data(), Speed, 10000);
}

uint32_t moveScanner(size_t SLHandle, const CartesianCoordinates& Target)
{
    return slsc_ctrl_move_scanner_abs(SLHandle, Target.data());
}

uint32_t resetAllRtcs(const std::string& ProgramPath)
{
    return slsc_util_reset_pcie(ProgramPath.c_str());
}

TrajectoryConfiguration::TrajectoryConfiguration()
    : Content(nullptr)
    , CreatedBySyncAxisDll(false)
{
}

TrajectoryConfiguration::TrajectoryConfiguration(TrajectoryConfiguration&& In) noexcept
    : Content(In.Content)
    , CreatedBySyncAxisDll(In.CreatedBySyncAxisDll)
{
    In.Content = nullptr;
}

TrajectoryConfiguration& TrajectoryConfiguration::operator=(TrajectoryConfiguration&& In)& noexcept
{
    if (&In != this)
    {
        Content = In.Content;
        CreatedBySyncAxisDll = In.CreatedBySyncAxisDll;
        In.Content = nullptr;
    }
    return *this;
}

TrajectoryConfiguration::~TrajectoryConfiguration() noexcept
{
    if (CreatedBySyncAxisDll == true)
    {
        slsc_cfg_delete_trajectory_config(&Content);
    }
    else
    {
        delete Content;
    }
}
