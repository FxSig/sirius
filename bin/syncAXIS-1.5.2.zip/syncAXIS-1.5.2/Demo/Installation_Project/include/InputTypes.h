/*
***************************************************************************
File: InputTypes.h

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#pragma once

#include <array>

namespace Constants
{
constexpr double PI = 3.14159265358979323846;       //!< PI
constexpr double TO_RAD = PI / 180.;                //!< conversion factor to rad
constexpr double EPSILON = 1e-12;                   //!< For comparisons of floating point numbers
}

//! Structure including a transformation matrix being calculated by the constructor.
struct TransformationMatrix
{
    explicit TransformationMatrix(double Angle);
    TransformationMatrix(double M11, double M12, double M21, double M22);

    double* data();
    const double* data() const;
    void setScale(double Scale);
private:
    std::array<double, 4> TransformationArray;
};

//! Basic Cartesian Coordinate structure.
struct CartesianCoordinates
{
    CartesianCoordinates();
    CartesianCoordinates(double X, double Y);
    //! data access functions
    double* data();
    const double* data() const;
    double& X();
    double X() const;
    double& Y();
    double Y() const;
    bool operator==(const CartesianCoordinates& In);
    CartesianCoordinates operator+(const CartesianCoordinates& Right);
    CartesianCoordinates operator-(const CartesianCoordinates& Right);
private:
    std::array<double, 2> PositionArray;
};

