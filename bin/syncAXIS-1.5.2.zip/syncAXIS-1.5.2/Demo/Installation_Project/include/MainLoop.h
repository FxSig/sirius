/*
***************************************************************************
File: MainLoop.h

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#pragma once

#include <string>
#include <vector>

#include "InputTypes.h"

//! \brief Struct that collects all setting options that are needed in the main loop.
struct InstanceSettings
{
    InstanceSettings();                         //!< Default initialization for instance settings.
    CartesianCoordinates Offset;                //!< Input data offset. (can be changed with an operation type)
    CartesianCoordinates PrevOffset;            //!< Last input data offset is saved.
    size_t SLHandle;                            //!< syncAXIS Control instance handle
    bool SuccessfulInit;                        //!< Shows if syncAXIS Control was successful initialized.
    uint32_t RetVal;                            //!< Saves the return types of function calls.
};
//! \brief Prints a welcome screen to the console.
void printWelcomeMessage();
//! \brief Runs the main loop. Switch-case for the different operation types.
bool mainLoop(InstanceSettings& MainInstanceSettings);
//! \brief Makes sure that on end of InstallationProject, the resources are freed.
void cleanup(InstanceSettings& MainInstanceSettings);
