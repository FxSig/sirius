/*
***************************************************************************
File: OperationTypesProcedures.h

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#pragma once

#include "InputTypes.h"

#include <vector>

//! Initialize syncAXIS Control instance
uint32_t initialize(size_t& SLHandle, const CartesianCoordinates& Offset);
//! Run basic test to check if laser is firing.
uint32_t checkLaserFiring(size_t SLHandle);
//! To check the communication of the system components, i.e. positioning stage, scan device and laser.
uint32_t referenceRun(size_t SLHandle);
//! First test marking to check the functionality of all components including syncAXIS control
//! Trajectory planning and ACS communication via the ACS SL2 - 100 to EtherCAT converter.
//! First impression of corner rounding thanks to blending or laser switching points in time in
//! the corners of the marking result.
uint32_t testMarking(size_t SLHandle);
//! To mark a grid in operation mode ScannerOnly to calibrate the scan device.The points can be
//! measured and passed to correXion pro in order to create an optimized correction file.
//! Ideally, the mechanical x axis is used as reference for the measurement. This Job moves
//! the x axis a few millimeters and then marks a reference point in the working field center.
uint32_t scannerCalibration(size_t SLHandle);
//! To mark a large grid in operation mode StageOnly.This marking pattern can be matched with a
//! calibration plate(glass master) to create the Error Mapping of the mechanical axes.
uint32_t stageCalibration(size_t SLHandle);
//! To mark a grid of selectable grid elements in operation mode ScannerAndStage(combined
//! motion).Can be used for measuring and evaluating. To reach higher positioning stage
//! velocities, a positioning stage path optimization motion segment can be included.
uint32_t combinedAccuracy(size_t SLHandle);
//! To mark a grid of objects (similar to a "H" pattern) in operation mode ScannerOnly at maximum
//! speed to optimize the laser switching points in time.Along the grid, LaserSwitchOffsetTime
//! and LaserPreTriggerTime are adjusted so that the object with the optimal laser switching
//! points in time can be selected from the array of objects.These values can then be used to
//! carry out this test again with finer iteration steps or to directly use the newly determined
//! laser delay values.
uint32_t checkLaserDelays(size_t SLHandle, CartesianCoordinates Offset);
//! To mark a grid in operation mode ScannerOnly (circles) and another one in operation mode
//! StageOnly(crosses).The grids can be compared to check the calibration quality.
uint32_t checkCalibrations(size_t SLHandle);
//! To mark rows of lines orthogonal to mechanical motion.The lines are executed in
//! positive and negative directions, and then repeated for all 4 spatial directions.The
//! objective is to check whether the lines of both mechanical motion directions are collinear or
//! whether an offset(in the direction of the mechanical motion) can be seen.In case the
//! lines are not collinear(offset in the direction of the mechanical motion), the positioning
//! stage motion is not perfectly synchronized with the scan device motion.If this is the
//! case, contact SCANLAB.An arrow indicates the mechanical direction of motion.
uint32_t checkSystemDelays(size_t SLHandle, const CartesianCoordinates& Offset);
//! To adapt a few settings like speeds and operation modes.Note that most Jobs use own
//! settings anyhow.Useful for the Job TEST_MARKING and to apply an offset, if the
//! to - be - marked area is not in the positioning stage center.
uint32_t changeSettingsMenu(size_t SLHandle,
                            CartesianCoordinates& Offset,
                            CartesianCoordinates& PrevOffset);
//! To destroy the syncAXIS control instance. Subsequently INIT must be carried out to
//! reload the syncAXISConfig.xml and to create a new syncAXIS control instance.
uint32_t deleteInstance(size_t& SLHandle);
