/*
***************************************************************************
File: MarkingPatterns.h

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#pragma once

#include "InputTypes.h"

#include <vector>
#include <functional>

//! An enum defining the command type. This enum is used to distinguish between various RTC vector and arc commands.
enum class CommandType : uint32_t
{
    MARK = 1,           //!< Initiate a slsc_list_mark_abs() command using Target as the vector end point coordinate.
    JUMP = 2,           //!< Initiate a slsc_list_jump_abs() command using Target as the vector end point coordinate.
    CIRCLE = 3,         //!< Initiate a slsc_list_circle_2d_abs() command using Target as the circle center position and 360&deg; arc angle.
    ARCMID = 4,         //!< Initiate a slsc_list_arc_abs() command using Mid as a point on the arc if followed by a ARCTARGET commandlist entry.
    ARCTARGET = 5,      //!< Initiate a slsc_list_arc_abs() command using Target as the end point of the arc if prerun by a ARCMID commandlist entry.
    CHANGESPEEDS = 6,   //!< Setting new jump speed (X coordinate) and mark speed (Y coordninate) valid for that job only.
    WAIT = 7,           //!< Inserting a point marking of duration Target.X and a wait of duration Target.Y.
};


//! Defines the Command2D structure being used to select and feed mark- and jump-commands by linking a CommandType with an vector end point coordinate.
struct Command2D
{
    Command2D();
    explicit Command2D(CommandType SetType, const CartesianCoordinates& SetTarget);

    CommandType Type;               //!< Type of RTC vector command.
    CartesianCoordinates Target ;   //!< Position at the vector end coordinates.
};

const Command2D& getHomeJump();
Command2D createWaitCommand(double T);
Command2D createChangeMarkSpeedCommand(double Speed);
Command2D createChangeJumpSpeedCommand(double Speed);
Command2D createChangeSpeedCommand(double JumpSpeed, double MarkSpeed);
Command2D createMarkCommand(double X, double Y);
Command2D createMarkCommand(const CartesianCoordinates& Target);
Command2D createJumpCommand(double X, double Y);
Command2D createJumpCommand(const CartesianCoordinates& Target);
Command2D createCircleCommand(double CenterX, double CenterY);
Command2D createCircleCommand(const CartesianCoordinates& Center);

//! Defines the commandList structure being used to create a list of single commands that can be executed to draw whole object, such as listed in the enum GeoType.
using CommandListType = std::vector<Command2D>;

CommandListType createArcCommand(double MidX, double MidY, double X, double Y);
CommandListType createArcCommand(const CartesianCoordinates& Mid, const CartesianCoordinates& Target);

CommandListType createSCANLABLogo(double ScalingFactor, const CartesianCoordinates& Center);
CommandListType createCircle(double Radius, double StartingAngle, const CartesianCoordinates& Center);
CommandListType createMultipleCircles(double OuterRadius, double MinRadius, double StepSize, double StartingAngle, const CartesianCoordinates& Center);
CommandListType createCross(double Crosslength, const CartesianCoordinates& Center);
CommandListType createDotArcs(double DotSize, double LaserSpotSize, const CartesianCoordinates& Center);
CommandListType createLine(const CartesianCoordinates& Start, const CartesianCoordinates& End, bool ReverseDirection);

CommandListType createGrid(const CartesianCoordinates& Start, const CartesianCoordinates& End, const CartesianCoordinates& StepSize, bool XDirection, bool RemoveLastSymbol, double FoV, std::function<CommandListType(CartesianCoordinates, int, int, double)> MarkingFigure);
CommandListType createGridWithStageSkyWriting(const CartesianCoordinates& Start, const CartesianCoordinates& End, const CartesianCoordinates& StepSize, bool XDirection, double FoV, double Bandwidth, double VStage, double ScalingFactor, double PrevJumpSpeed, double MinWaitTime, std::function<CommandListType(CartesianCoordinates, int, int, double)> MarkingFigure);
CommandListType createStageSkyWritingInX(const CartesianCoordinates& PrevPosition, const CartesianCoordinates& NextPosition, int Direction, bool& IsFirstOrLast, double Bandwidth, double VStage, double ScalingFactor, double PrevJumpSpeed, double MinWaitTime);
CommandListType createStageSkyWritingInY(const CartesianCoordinates& PrevPosition, const CartesianCoordinates& NextPosition, int Direction, bool& IsFirstOrLast, double Bandwidth, double VStage, double ScalingFactor, double PrevJumpSpeed, double MinWaitTime);

CommandListType mergeCommandLists(const std::vector<CommandListType>& Elements);
CommandListType mergeCommandLists(const CommandListType& List1, const CommandListType& List2);
void appendCommandList(CommandListType& ResultingList, const CommandListType& InputList);

void changeDirection(int& Direction, double& Position, double Start, double End);
