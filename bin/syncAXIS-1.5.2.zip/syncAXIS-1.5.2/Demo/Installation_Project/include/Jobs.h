/*
***************************************************************************
File: Jobs.h

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#pragma once

#include "MarkingPatterns.h"
#include "DemoFunctions.h"

uint32_t writeTestMarking(size_t SLHandle, size_t& JobID, double ScalingFactor);
uint32_t writeGridWithModule(size_t Handle, const CartesianCoordinates& Start, const CartesianCoordinates& End, const CartesianCoordinates& StepSize, bool XDirection, double FoV, const char* Module);
uint32_t writeScannerCalibrationGrid(size_t SLHandle, size_t& JobID, const CartesianCoordinates& Start, const CartesianCoordinates& End, const CartesianCoordinates& StepSize, const char* ModuleName);
uint32_t writeStageAlignmentPoint(size_t SLHandle, size_t& JobID);
uint32_t writeScannerVerificationGrid(size_t SLHandle, size_t& JobID, const CartesianCoordinates& Start, const CartesianCoordinates& End, const CartesianCoordinates& StepSize);
uint32_t writeStageVerificationGrid(size_t SLHandle, size_t& JobID, const CartesianCoordinates& Start, const CartesianCoordinates& End, const CartesianCoordinates& StepSize);
uint32_t writeCombinedAccuracyJob(size_t SLHandle, size_t& JobID, const CartesianCoordinates& Start, const CartesianCoordinates& End, const CartesianCoordinates& StepSize, double FoV, const Geometries& Geometry, bool UseStageSkyWriting, double vStage, double Bandwidth, double ScalingFactor);
uint32_t executeReferenceRun(size_t SLHandle, double ScannerWidth, double StageWidth, double StageSpeed);
uint32_t executeTestMarking(size_t SLHandle, double ScalingFactor, bool AutoStart = false);
uint32_t executeCalibrationCheck(size_t SLHandle, double GridSize, int NumberOfGridPoints, double StageSpeed, bool AutoStart = false);
uint32_t executeScannerCalibrationJob(size_t SLHandle, double GridSize, int NumberOfGridPoints, double StageSpeed, bool AutoStart = false);
uint32_t executeStageCalibrationJob(size_t SLHandle, double GridSize, int NumberOfGridPoints, double StageSpeed, bool AutoStart = false);
uint32_t executeLaserDelayCheck(size_t SLHandle, double VScanner, double StartSwitchOffset, double IncrementSwitchOffset, double StartPreTrigger, double IncrementPreTrigger, CartesianCoordinates GlobalOffset, bool AutoStart = false);
uint32_t executeSystemDelayCheck(size_t SLHandle, double VStage, double RStage, CartesianCoordinates GlobalOffset, bool AutoStart = false);
uint32_t executeStageMovement(size_t SLHandle, const CartesianCoordinates& Position, double StageSpeed);
uint32_t executeCombinedAccuracyJob(size_t SLHandle, double GridSize, int NumberOfGridPoints, double FoV, const Geometries& Geometry, bool UseStageSkyWriting, double vStage, double Bandwidth, double ScalingFactor, bool AutoStart = false);
uint32_t createSpiralModule(size_t SLHandle, const char* ModuleName);
