/*
***************************************************************************
File: ConfigFileSearch.h

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#pragma once

#include <vector>
#include <string>

std::vector<std::string> readConfigFileNames(const std::string& ConfigFileDir);
std::vector<std::string> readConfigFileNamesInExeDir(std::string& ReturnExeDir);
