/*
***************************************************************************
File: InputTypes.cpp

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#include "InputTypes.h"

#include <cmath>

TransformationMatrix::TransformationMatrix(double M11, double M12, double M21, double M22)
    : TransformationArray( { M11, M12, M21, M22 })
{
}

TransformationMatrix::TransformationMatrix(double Angle)
    : TransformationMatrix(cos(Angle * Constants::TO_RAD), -sin(Angle * Constants::TO_RAD), sin(Angle * Constants::TO_RAD), cos(Angle * Constants::TO_RAD))
{
}

void TransformationMatrix::setScale(double Scale)
{
    for (auto& Ele : TransformationArray)
    {
        Ele *= Scale;
    }
};

double* TransformationMatrix::data()
{
    return TransformationArray.data();
}

const double* TransformationMatrix::data() const
{
    return TransformationArray.data();
}

CartesianCoordinates::CartesianCoordinates()
    : CartesianCoordinates(0, 0)
{
}

CartesianCoordinates::CartesianCoordinates(double X, double Y)
    : PositionArray( { X, Y })
{
}

double* CartesianCoordinates::data()
{
    return PositionArray.data();
}

const double* CartesianCoordinates::data() const
{
    return PositionArray.data();
}

double& CartesianCoordinates::X()
{
    return PositionArray[0];
}

double CartesianCoordinates::X() const
{
    return PositionArray[0];
}

double& CartesianCoordinates::Y()
{
    return PositionArray[1];
}

double CartesianCoordinates::Y() const
{
    return PositionArray[1];
}


bool CartesianCoordinates::operator==(const CartesianCoordinates& In)
{
    return X() == In.X() && Y() == In.Y();
}

CartesianCoordinates CartesianCoordinates::operator+(const CartesianCoordinates& Right)
{
    return CartesianCoordinates(X() + Right.X(), Y() + Right.Y());
}

CartesianCoordinates CartesianCoordinates::operator-(const CartesianCoordinates& Right)
{
    return CartesianCoordinates(X() - Right.X(), Y() - Right.Y());
}