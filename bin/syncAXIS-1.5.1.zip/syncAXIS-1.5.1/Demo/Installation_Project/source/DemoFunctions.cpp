/*
***************************************************************************
File: DemoFunctions.cpp

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#include "DemoFunctions.h"

#include "Jobs.h"
#include "syncAXISControl.h"

const std::map<OperationType, StringDuplet>& getOperationCaseDescriptions()
{
    static std::map<OperationType, StringDuplet> OperationCaseDescriptions
    {
        { OperationType::EXIT,                  { "Leave application", "EXIT" } },
        { OperationType::INIT,                  { "Initialize an instance from an XML file", "INIT" } },
        { OperationType::REFERENCE_RUN,         { "Execute a reference run with each scanner and stage to check for correct configuration", "REFERENCE_RUN" } },
        { OperationType::CHECK_LASER_FIRING,    { "Check for correct laser configuration by firing the laser manually without any motion", "CHECK_LASER_FIRING" } },
        { OperationType::TEST_MARKING,          { "Mark a test pattern (SCANLAB logo) with the current settings", "TEST_MARKING" } },
        { OperationType::SCANNER_CALI,          { "Execute marking of a scanner calibration grid in ScannerOnly-mode", "SCANNER_CALI" } },
        { OperationType::STAGE_CALI,            { "Execute marking of a stage calibration grid", "STAGE_CALI" } },
        { OperationType::COMBINED_ACCURACY,     { "Mark a grid in combined motion for evaluation of combined accuracy", "COMBINED_ACCURACY" } },
        { OperationType::CHECK_CALIBRATIONS,    { "Execute an accuracy test pattern consisting of a circle grid pattern in ScannerOnly and a cross grid pattern in StageOnly-mode that can be compared", "CHECK_CALIBRATIONS" } },
        { OperationType::CHECK_LASERDELAYS,     { "Draw a marking pattern for checking the laser delays", "CHECK_LASERDELAYS" } },
        { OperationType::CHECK_SYSTEMDELAYS,    { "Draw a marking pattern for checking the system delays (should be good by default. Please contact SCANLAB in case they are not)", "CHECK_SYSTEMDELAYS" } },
        { OperationType::CHANGE_SETTINGS,       { "Change settings of the job like speed, offset, etc.", "CHANGE_SETTINGS" } },
        { OperationType::DELETE_INSTANCE,       { "Delete instance without terminating the application", "DELETE_INSTANCE" } },
        { OperationType::CHECK_FOR_ERRORS,      { "Check for errors", "CHECK_FOR_ERRORS" } },
    };
    return OperationCaseDescriptions;
}
StringDuplet getOperationCaseDescriptions(OperationType Input)
{
    return getOperationCaseDescriptions().at(Input);
}

const std::map<std::string, OperationType>& getOperationCases()
{
    static std::map<std::string, OperationType> OperationCases
    {
        { "EXIT",                                                               OperationType::EXIT },
        { "INIT",                                                               OperationType::INIT },
        { "REFERENCE_RUN",                                                      OperationType::REFERENCE_RUN },
        { "CHECK_LASER_FIRING",                                                 OperationType::CHECK_LASER_FIRING },
        { "TEST_MARKING",                                                       OperationType::TEST_MARKING },
        { "SCANNER_CALI",                                                       OperationType::SCANNER_CALI },
        { "STAGE_CALI",                                                         OperationType::STAGE_CALI },
        { "COMBINED_ACCURACY",                                                  OperationType::COMBINED_ACCURACY },
        { "CHECK_CALIBRATIONS",                                                 OperationType::CHECK_CALIBRATIONS },
        { "CHECK_LASERDELAYS",                                                  OperationType::CHECK_LASERDELAYS },
        { "CHECK_SYSTEMDELAYS",                                                 OperationType::CHECK_SYSTEMDELAYS },
        { "CHANGE_SETTINGS",                                                    OperationType::CHANGE_SETTINGS },
        { "DELETE_INSTANCE",                                                    OperationType::DELETE_INSTANCE },
        { "CHECK_FOR_ERRORS",                                                   OperationType::CHECK_FOR_ERRORS },

        { std::to_string(static_cast<int>(OperationType::EXIT)),                OperationType::EXIT },
        { std::to_string(static_cast<int>(OperationType::INIT)),                OperationType::INIT },
        { std::to_string(static_cast<int>(OperationType::REFERENCE_RUN)),       OperationType::REFERENCE_RUN },
        { std::to_string(static_cast<int>(OperationType::CHECK_LASER_FIRING)),  OperationType::CHECK_LASER_FIRING },
        { std::to_string(static_cast<int>(OperationType::TEST_MARKING)),        OperationType::TEST_MARKING },
        { std::to_string(static_cast<int>(OperationType::SCANNER_CALI)),        OperationType::SCANNER_CALI },
        { std::to_string(static_cast<int>(OperationType::STAGE_CALI)),          OperationType::STAGE_CALI },
        { std::to_string(static_cast<int>(OperationType::COMBINED_ACCURACY)),   OperationType::COMBINED_ACCURACY },
        { std::to_string(static_cast<int>(OperationType::CHECK_CALIBRATIONS)),  OperationType::CHECK_CALIBRATIONS },
        { std::to_string(static_cast<int>(OperationType::CHECK_LASERDELAYS)),   OperationType::CHECK_LASERDELAYS },
        { std::to_string(static_cast<int>(OperationType::CHECK_SYSTEMDELAYS)),  OperationType::CHECK_SYSTEMDELAYS },
        { std::to_string(static_cast<int>(OperationType::CHANGE_SETTINGS)),     OperationType::CHANGE_SETTINGS },
        { std::to_string(static_cast<int>(OperationType::DELETE_INSTANCE)),     OperationType::DELETE_INSTANCE },
        { std::to_string(static_cast<int>(OperationType::CHECK_FOR_ERRORS)),    OperationType::CHECK_FOR_ERRORS },
    };
    return OperationCases;
}

OperationType getOperationCases(const std::string& Input)
{
    return getOperationCases().at(Input);
}

const std::map<SettingsType, StringDuplet>& getChangeSettingCaseDescriptions()
{
    static std::map<SettingsType, StringDuplet> ChangeSettingCaseDescriptions
    {
        { SettingsType::EXIT,               { "Leave the settings menu - go back to the job menu", "EXIT" } },
        { SettingsType::OPMODE,             { "Change operation mode", "OPMODE" } },
        { SettingsType::SPEEDS,             { "Change speed settings", "SPEEDS" } },
        { SettingsType::OFFSET,             { "Change the coordinate offset", "OFFSET" } }
    };
    return ChangeSettingCaseDescriptions;
}

StringDuplet getChangeSettingCaseDescriptions(SettingsType Input)
{
    return getChangeSettingCaseDescriptions().at(Input);
}

const std::map<std::string, SettingsType>& getChangeSettingCases()
{
    static std::map<std::string, SettingsType> ChangeSettingCases
    {
        { "EXIT",                                                               SettingsType::EXIT },
        { "OPMODE",                                                             SettingsType::OPMODE },
        { "OFFSET",                                                             SettingsType::OFFSET},
        { "SPEEDS",                                                             SettingsType::SPEEDS },

        { std::to_string(static_cast<int>(SettingsType::EXIT)),                 SettingsType::EXIT },
        { std::to_string(static_cast<int>(SettingsType::OPMODE)),               SettingsType::OPMODE },
        { std::to_string(static_cast<int>(SettingsType::SPEEDS)),               SettingsType::SPEEDS },
        { std::to_string(static_cast<int>(SettingsType::OFFSET)),               SettingsType::OFFSET }
    };
    return ChangeSettingCases;
}

SettingsType getChangeSettingCases(const std::string& Input)
{
    return getChangeSettingCases().at(Input);
}

const std::map<Geometries, StringDuplet>& getGeometryCaseDescriptions()
{
    static std::map<Geometries, StringDuplet> GeometryCaseDescriptions
    {
        { Geometries::NONE,         { "Not marking any pattern (also default)", "NONE" } },
        { Geometries::CIRCLE,       { "Marking a pattern of single circles", "CIRCLE" } },
        { Geometries::TWO_CIRCLES,  { "Marking a pattern of two concentric circles", "TWO_CIRCLES" } },
        { Geometries::CROSS,        { "Marking a pattern of crosses", "CROSS" } },
        { Geometries::DOT,          { "Marking a pattern of dots", "DOT" } }
    };
    return GeometryCaseDescriptions;
}

StringDuplet getGeometryCaseDescriptions(Geometries Input)
{
    return getGeometryCaseDescriptions().at(Input);
}

const std::map<std::string, Geometries>& getGeometryCases()
{
    static std::map<std::string, Geometries> GeometryCases
    {
        { "NONE",                                                       Geometries::NONE},
        { "CIRCLE",                                                     Geometries::CIRCLE},
        { "TWO_CIRCLES",                                                Geometries::TWO_CIRCLES},
        { "CROSS",                                                      Geometries::CROSS},
        { "DOT",                                                        Geometries::DOT},

        { std::to_string(static_cast<int>(Geometries::NONE)),           Geometries::NONE},
        { std::to_string(static_cast<int>(Geometries::CIRCLE)),         Geometries::CIRCLE},
        { std::to_string(static_cast<int>(Geometries::TWO_CIRCLES)),    Geometries::TWO_CIRCLES},
        { std::to_string(static_cast<int>(Geometries::CROSS)),          Geometries::CROSS},
        { std::to_string(static_cast<int>(Geometries::DOT)),            Geometries::DOT}
    };
    return GeometryCases;
}
Geometries getGeometryCases(const std::string& Input)
{
    return getGeometryCases().at(Input);
}

void printSeparationLine()
{
    std::cout << std::endl << std::string(80, '#') << std::endl << std::endl;
    return;
}

bool expectPositiveDouble(double Input)
{
    bool InputAsExpected = (Input > 0.0);
    if (!InputAsExpected)
    {
        std::cout << "Invalid input. Expected a positive double value." << std::endl << "Please try again: ";
    }
    return InputAsExpected;
}

bool expectDoubleBetween0And1(double Input)
{
    bool InputAsExpected = ((Input >= 0.0) && (Input <= 1.0));
    if (!InputAsExpected)
    {
        std::cout << "Invalid input. Expected a double value between 0 and 1." << std::endl << "Please try again: ";
    }
    return InputAsExpected;
}

bool expectAnyDouble(double Input)
{
    (void)Input;
    return true;
}

bool expectOddIntGreater1(int Input)
{
    bool InputAsExpected = (Input > 1) && (Input % 2 == 1);
    if (!InputAsExpected)
    {
        std::cout << "Invalid input. Expected an odd integer value > 1." << std::endl << "Please try again: ";
    }
    return InputAsExpected;
}

bool expectNonNegativeInt(int Input)
{
    bool InputAsExpected = (Input > -1);
    if (!InputAsExpected)
    {
        std::cout << "Invalid input. Expected a non-negative integer value." << std::endl << "Please try again: ";
    }
    return InputAsExpected;
}

bool expectAnyInt(int Input)
{
    (void)Input;
    return true;
}

bool tryReadingBool()
{
    bool ResultIsGood = false;
    bool Result = false;
    std::string Input;
    while (ResultIsGood == false)
    {
        while (!(std::cin >> Input))
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input (probably non-string)." << std::endl << "Please try again:";
        }
        if (Input == "1" || Input == "y" || Input == "Y")
        {
            Result = true;
            ResultIsGood = true;
        }
        else if (Input == "0" || Input == "n" || Input == "N")
        {
            Result = false;
            ResultIsGood = true;
        }
        else
        {
            std::cout << "Invalid input (probably non-boolean)." << std::endl << "Please try again:";
        }
    }

    return Result;
};

int tryReadingInt(std::function<bool(int)> ValidationFunc)
{
    size_t Input;
    bool InputOK = false;
    while (!InputOK)
    {
        if (!(std::cin >> Input))
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input (probably non-integer)." << std::endl << "Please try again: ";
        }
        else
        {
            if (ValidationFunc(Input))
            {
                InputOK = true;
            }
        }
    }
    return Input;
};

double tryReadingDouble(std::function<bool(double)> ValidationFunc)
{
    double Input;
    bool InputOK = false;
    while (!InputOK)
    {
        if (!(std::cin >> Input))
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input (probably non-double)." << std::endl << "Please try again: ";
        }
        else
        {
            if (ValidationFunc(Input))
            {
                InputOK = true;
            }
        }
    }
    return Input;
}
size_t readConfigFileIndex(const std::vector<std::string>& ConfigFilePaths)
{
    std::cout << std::endl << "Please enter the number of the config file to be used." << std::endl;
    std::cout << "Available config files are: " << std::endl;
    for (size_t i = 0; i < ConfigFilePaths.size(); i++)
    {
        std::cout << i + 1 << ": " << ConfigFilePaths[i] << std::endl;
    }

    size_t ConfigFilesIndex = 0;
    while (ConfigFilesIndex == 0)
    {
        std::cout << "Please enter the number of the config file to be used:";
        ConfigFilesIndex = tryReadingInt(expectAnyInt);

        if ((ConfigFilesIndex > ConfigFilePaths.size()) || (ConfigFilesIndex <= 0))
        {
            std::cout << "Inserted number exceeds number of config files, please try again..." << std::endl << std::endl;
            ConfigFilesIndex = 0;
        }
    }
    return ConfigFilesIndex;
}
double readScalingFactor()
{
    double ScalingFactor = 1.0;
    std::cout << "Specify the size of your first test marking in [mm]." << std::endl <<
              "In ScannerOnly-mode, the pattern should fit inside the scanner field of view." << std::endl <<
              "Please enter: ";
    ScalingFactor = tryReadingDouble(expectPositiveDouble);
    std::cout << " " << std::endl << std::endl;
    return ScalingFactor;
}

Geometries readGeometry()
{
    std::string GeometryString;
    while (true)
    {
        printOptions(getGeometryCaseDescriptions());
        std::cin >> GeometryString;
        if (getGeometryCases().count(GeometryString) == 0)
        {
            std::cout << "The chosen option does not exist. Please try again.\n";
        }
        else
        {
            break;
        }
    }
    const Geometries Case = getGeometryCases(GeometryString);
    std::cout << std::endl << "You chose case " << GeometryString << " (" << getGeometryCaseDescriptions(Case).Brief << ") -> \""
              << getGeometryCaseDescriptions(Case).Description << "\"" << std::endl << std::endl;
    return Case;
}

bool checkForSuccessfulInit(bool SuccessfulInit, uint32_t RetVal)
{
    if (!SuccessfulInit)
    {
        std::cout << "Initialize first." << std::endl;
        return false;
    }
    else if (RetVal != 0)
    {
        std::cout << "Successful initialized, however, return value is " << RetVal << std::endl;
        return false;
    }

    return true;
}

uint32_t printJobCharacteristics(size_t SLHandle, size_t JobID, double FoV)
{
    uint32_t RetVal = 0;
    std::cout << "The job characteristics are: " << std::endl;

    std::map<slsc_JobCharacteristic, std::pair<std::string, double>> JobCharacteristics;
    RetVal |= getJobCharacteristic(SLHandle, JobCharacteristics, JobID);
    for (const auto& JobChara : JobCharacteristics)
    {
        std::cout << JobChara.second.first << " = " << JobChara.second.second << std::endl;
    }
    if (FoV > 0)
    {
        double ScannerMaxX = JobCharacteristics[slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerPosX].second;
        double ScannerMaxY = JobCharacteristics[slsc_JobCharacteristic::slsc_JobCharacteristic_ScannerPosY].second;

        std::cout << "This results in an maximum field of view of "
                  << std::max(ScannerMaxX, ScannerMaxY) << "mm, which equals "
                  << std::max(ScannerMaxX, ScannerMaxY) / (FoV / 2) * 100 << "% of the scanner field of view."
                  << std::endl;
    }
    return RetVal;
}

void changeOffset(double Offsetsize, double Angle, CartesianCoordinates& Offset)
{
    switch (((int)Angle) % 360)
    {
        case 90:
            Offset.X() += Offsetsize;
            Offset.Y() += Offsetsize;
            break;
        case 180:
            Offset.X() -= Offsetsize;
            Offset.Y() += Offsetsize;
            break;
        case 270:
            Offset.X() -= Offsetsize;
            Offset.Y() -= Offsetsize;
            break;
        case 0:
            Offset.X() += Offsetsize;
            Offset.Y() -= Offsetsize;
            break;
        default:
            break;
    }
}

uint32_t changeOperationMode(size_t SLHandle,
                             CartesianCoordinates& Offset,
                             CartesianCoordinates& PrevOffset)
{
    uint32_t RetVal = 0;
    bool Repeat = true;
    while (Repeat)
    {
        Repeat = false;
        Offset = PrevOffset;
        std::cout << "Which mode should be used?" << std::endl <<
                  "Enter 1: OperationMode_ScannerOnly. (SCANNER) " << std::endl <<
                  "Enter 2: OperationMode_StageOnly. (STAGEONLY)" << std::endl <<
                  "Enter 3: OperationMode_ScannerAndStage (SCANNERANDSTAGE)." << std::endl <<
                  "Enter 0: Keep the settings (EXIT)" << std::endl;
        std::cout << "Enter mode: ";
        std::string Mode;
        std::cin >> Mode;

        if (Mode == "1" || Mode == "SCANNER")
        {
            std::cout << "Do you want to move the stage to the offset position? (y/n)" << std::endl <<
                      "(The Offset will be set to 0 until the next change of operation mode.) \nEnter y or n:" << std::endl;

            if (tryReadingBool())
            {
                std::cout << "The stage will be moved! Keep clear of the stage!\nPlease enter the stage speed: ";
                double StageSpeed = tryReadingDouble(expectPositiveDouble);

                RetVal |= executeStageMovement(SLHandle, CartesianCoordinates(), StageSpeed);
                PrevOffset = Offset;
                Offset = CartesianCoordinates();
            }
            else
            {
                std::cout << "Offset is not changed." << std::endl;
            }

            RetVal |= setMode(SLHandle, slsc_OperationMode::slsc_OperationMode_ScannerOnly);
            std::cout << "The operation mode is now ScannerOnly." << std::endl;
        }
        else if (Mode == "2" || Mode == "STAGECALI")
        {
            RetVal |= setMode(SLHandle, slsc_OperationMode::slsc_OperationMode_StageOnly);
            std::cout << "The operation mode is now StageOnly." << std::endl;
        }
        else if (Mode == "3" || Mode == "SCANNERANDSTAGE")
        {
            RetVal |= setMode(SLHandle, slsc_OperationMode::slsc_OperationMode_ScannerAndStage);
            std::cout << "The operation mode is now ScannerAndStage." << std::endl;
        }
        else if (Mode == "0" || Mode == "EXIT")
        {
            return RetVal;
        }
        else
        {
            Repeat = true;
            std::cout << "Invalid input. Please try again..." << std::endl;
        }
    }
    return RetVal;
}


uint32_t changeSpeed(size_t SLHandle)
{
    uint32_t RetVal = 0;
    bool Repeat = true;
    while (Repeat)
    {
        Repeat = false;
        std::cout << "Which speed should be changed?" << std::endl <<
                  "Enter 0 to keep previous settings (EXIT)" << std::endl <<
                  "Enter 1 to change jump speed (JUMP)." << std::endl <<
                  "Enter 2 to change mark speed (MARK)." << std::endl;
        std::cout << "Enter: ";
        std::string SpeedType;
        std::cin >> SpeedType;
        if (SpeedType == "1" || SpeedType == "JUMP")
        {
            std::cout << "Enter new jump speed: ";
            const double JumpSpeed = tryReadingDouble(expectPositiveDouble);
            RetVal |= cfgSetJumpSpeed(SLHandle, JumpSpeed);
            std::cout << "Jump speed is now " << JumpSpeed << "." << std::endl;

        }
        else if ((SpeedType == "2" || SpeedType == "MARK"))
        {
            std::cout << "Enter new mark speed: ";
            const double MarkSpeed = tryReadingDouble(expectPositiveDouble);
            RetVal |= cfgSetMarkSpeed(SLHandle, MarkSpeed);
            std::cout << "Mark speed is now " << MarkSpeed << "." << std::endl;

        }
        else if ((SpeedType == "0" || SpeedType == "EXIT"))
        {
            return RetVal;
        }
        else
        {
            Repeat = true;
            std::cout << "Invalid input. Please try again..." << std::endl;
        }
    }
    return RetVal;
}

void changeConfigFilePath(std::vector<std::string>& ConfigFilePathes, size_t& ConfigFileIndex)
{
    size_t InputInt;
    std::cout << "The current config file path is: " << ConfigFilePathes[ConfigFileIndex] << std::endl << std::endl;

    std::cout << "Please choose the correct config file path. (Integer value)" << std::endl;
    std::cout << "Enter 0 to add a new path." << std::endl;
    for (size_t i = 0; i < ConfigFilePathes.size(); i++)
    {
        std::cout << "Enter " << i + 1 << " for file " << ConfigFilePathes[i] << "." << i + 1 << std::endl;
    }
    std::cout << "Please enter: ";
    InputInt = tryReadingInt(expectNonNegativeInt);

    if (InputInt == 0)
    {
        std::string InputStream;
        std::cout << "Please enter the new path of the config file: ";
        std::cin >> InputStream;

        ConfigFilePathes.push_back(InputStream);
        ConfigFileIndex = ConfigFilePathes.size() - 1;
    }
    else if (InputInt > 0 && InputInt <= ConfigFilePathes.size())
    {
        ConfigFileIndex = InputInt - 1;
    }

    std::cout << std::endl << "The new config file path is: " << ConfigFilePathes[ConfigFileIndex] << std::endl;
    return;
}


