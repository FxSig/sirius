/*
***************************************************************************
File: MainLoop.cpp

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#include "MainLoop.h"

#include "OperationTypesProcedures.h"
#include "DemoFunctions.h"

#include <future>

InstanceSettings::InstanceSettings()
    : Offset(0., 0.)
    , PrevOffset(Offset)
    , SLHandle(0)
    , SuccessfulInit(false)
    , RetVal(1)
{
}

void printWelcomeMessage()
{
    std::cout << std::endl <<
              "        #########################################################################" << std::endl <<
              "        ##                                                                     ##" << std::endl <<
              "        ##        Welcome to the syncAXIS control Installation Project         ##" << std::endl <<
              "        ##                                                                     ##" << std::endl <<
              "        ##          This program demonstrates the implementation of            ##" << std::endl <<
              "        ##       the syncAXIS control software for controlling XL SCAN.        ##" << std::endl <<
              "        ##                                                                     ##" << std::endl <<
              "        ##   Before starting the program, make sure the syncAXISConfig.xml     ##" << std::endl <<
              "        ##     file is correctly set (i.e. adding the ACS controllers IP       ##" << std::endl <<
              "        ##                 address and correction file path)                   ##" << std::endl <<
              "        ##    and placed in a specified location or the execution directory.   ##" << std::endl <<
              "        ##                                                                     ##" << std::endl <<
              "        #########################################################################" << std::endl << std::endl;
    return;
}

bool mainLoop(InstanceSettings& MainInstanceSettings)
{
    size_t& SLHandle = MainInstanceSettings.SLHandle;
    uint32_t& RetVal = MainInstanceSettings.RetVal;
    CartesianCoordinates& Offset = MainInstanceSettings.Offset;
    CartesianCoordinates& PrevOffset = MainInstanceSettings.PrevOffset;
    bool& SuccessfulInit = MainInstanceSettings.SuccessfulInit;

    bool Repeat = true;
    std::string InputString;
    printOptions(getOperationCaseDescriptions());
    std::cin >> InputString;

    if (getOperationCases().count(InputString) > 0)
    {

        const OperationType Case = getOperationCases(InputString);
        std::cout << std::endl << "You chose case " << InputString << " (" << getOperationCaseDescriptions(Case).Brief << ") -> \""
                  << getOperationCaseDescriptions(Case).Description << "\"" << std::endl << std::endl;
        printSeparationLine();

        switch (Case)
        {
            case OperationType::EXIT:
            {
                Repeat = false;
                break;
            }
            case OperationType::INIT:
            {
                RetVal = initialize(SLHandle, Offset);
                MainInstanceSettings.SuccessfulInit = (RetVal == 0);
                break;
            }
            case OperationType::CHECK_LASER_FIRING:
            {
                if (checkForSuccessfulInit(SuccessfulInit, RetVal))
                {
                    RetVal |= checkLaserFiring(SLHandle);
                }
                break;
            }
            case OperationType::REFERENCE_RUN:
            {
                if (checkForSuccessfulInit(SuccessfulInit, RetVal))
                {
                    RetVal |= referenceRun(SLHandle);
                }
                break;
            }
            case OperationType::TEST_MARKING:
            {
                if (checkForSuccessfulInit(SuccessfulInit, RetVal))
                {
                    RetVal |= testMarking(SLHandle);
                }
                break;
            }
            case OperationType::SCANNER_CALI:
            {
                if (checkForSuccessfulInit(SuccessfulInit, RetVal))
                {
                    RetVal |= scannerCalibration(SLHandle);
                }
                break;
            }
            case OperationType::STAGE_CALI:
            {
                if (checkForSuccessfulInit(SuccessfulInit, RetVal))
                {
                    RetVal |= stageCalibration(SLHandle);
                }
                break;
            }
            case OperationType::COMBINED_ACCURACY:
            {
                if (checkForSuccessfulInit(SuccessfulInit, RetVal))
                {
                    RetVal |= combinedAccuracy(SLHandle);
                }
                break;
            }
            case OperationType::CHECK_LASERDELAYS:
            {
                if (checkForSuccessfulInit(SuccessfulInit, RetVal))
                {
                    RetVal |= checkLaserDelays(SLHandle, Offset);
                }
                break;
            }
            case OperationType::CHECK_CALIBRATIONS:
            {
                if (checkForSuccessfulInit(SuccessfulInit, RetVal))
                {
                    RetVal |= checkCalibrations(SLHandle);
                }
                break;
            }
            case OperationType::CHECK_SYSTEMDELAYS:
            {
                if (checkForSuccessfulInit(SuccessfulInit, RetVal))
                {
                    RetVal |= checkSystemDelays(SLHandle, Offset);
                }
                break;
            }
            case OperationType::CHANGE_SETTINGS:
            {
                if (checkForSuccessfulInit(SuccessfulInit, RetVal))
                {
                    RetVal |= changeSettingsMenu(SLHandle, Offset, PrevOffset);
                }
                break;
            }
            case OperationType::DELETE_INSTANCE:
            {
                RetVal = deleteInstance(SLHandle);
                SuccessfulInit = false;
                break;
            }
            case OperationType::CHECK_FOR_ERRORS:
            {
                RetVal |= checkForErrors(SLHandle);
                break;
            }
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(100));

        std::cout << std::endl << std::endl << "Case " << InputString << " (" << getOperationCaseDescriptions(Case).Brief << ") finished with return value: " << RetVal << "." << std::endl << std::endl;
        printSeparationLine();

    }
    return Repeat;
}

void cleanup(InstanceSettings& MainInstanceSettings)
{
    MainInstanceSettings.RetVal = deleteInstance(MainInstanceSettings.SLHandle);
}
