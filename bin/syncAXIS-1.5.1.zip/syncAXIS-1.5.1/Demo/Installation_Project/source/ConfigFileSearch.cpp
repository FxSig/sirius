/*
***************************************************************************
File: ConfigFileSearch.cpp

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#include "ConfigFileSearch.h"

#include <windows.h>
#include <array>

std::vector<std::string> readConfigFileNames(const std::string& ConfigFileDir)
{
    std::vector<std::string> FoundConfigFileNames;
    std::string SearchFilePath = ConfigFileDir + "\\*.xml";
    WIN32_FIND_DATA FindFileData;
    HANDLE FindHandle;

    FindHandle = FindFirstFileA(SearchFilePath.c_str(), &FindFileData);
    if (FindHandle == INVALID_HANDLE_VALUE)
    {
        return FoundConfigFileNames;
    }
    FoundConfigFileNames.push_back(FindFileData.cFileName);

    while (0 != FindNextFileA(FindHandle, &FindFileData))
    {
        FoundConfigFileNames.push_back(FindFileData.cFileName);
    }

    FindClose(FindHandle);

    return FoundConfigFileNames;
}

std::vector<std::string> readConfigFileNamesInExeDir(std::string& ReturnExeDir)
{
    std::array<char, _MAX_PATH> Buffer;
    GetCurrentDirectoryA(_MAX_PATH, Buffer.data());
    ReturnExeDir = Buffer.data();

    return readConfigFileNames(ReturnExeDir);
}
