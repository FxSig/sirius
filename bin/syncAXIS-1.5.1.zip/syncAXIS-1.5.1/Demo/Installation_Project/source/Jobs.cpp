/*
***************************************************************************
File: Jobs.cpp

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#include "Jobs.h"
#include "syncAXISControl.h"

#include <future>
#include <cmath>

constexpr double EPSILON = Constants::EPSILON;

uint32_t writeTestMarking(size_t SLHandle, size_t& JobID, double ScalingFactor)
{
    CommandListType TestMarking = createSCANLABLogo(ScalingFactor, CartesianCoordinates());

    TestMarking.push_back(getHomeJump());

    return writeJob(SLHandle, JobID, TestMarking);
}



uint32_t writeScannerCalibrationGrid(size_t SLHandle, size_t& JobID, const CartesianCoordinates& Start, const CartesianCoordinates& End, const CartesianCoordinates& StepSize, const char* ModuleName)
{
    uint32_t RetVal = 0;
    CartesianCoordinates Position = Start;
    std::vector<CartesianCoordinates> PositionList;
    int Direction = 1;
    int BiDirectionality = 1;

    while (((Position.Y() >= Start.Y() - EPSILON) && (Position.Y() <= End.Y() + EPSILON))
           ||
           ((Position.Y() <= Start.Y() + EPSILON) && (Position.Y() >= End.Y() - EPSILON)))
    {
        BiDirectionality = 1;
        changeDirection(Direction, Position.X(), Start.X(), End.X());

        while (((Position.X() >= Start.X() - EPSILON) && (Position.X() <= End.X() + EPSILON))
               ||
               ((Position.X() <= Start.X() + EPSILON) && (Position.X() >= End.X() - EPSILON)))
        {
            PositionList.push_back(Position);
            Position.X() += Direction*StepSize.X();
            BiDirectionality *= -1;
        }
        Position.Y() += StepSize.Y();
    }

    RetVal = writeJobOnModuleList(SLHandle, JobID, PositionList, ModuleName);

    return RetVal;
}

uint32_t writeStageAlignmentPoint(size_t SLHandle, size_t& JobID)
{
    const double SpotSize = 1;
    const double LaserSpotSize = 0.05;
    const double CircleRadius = 2;
    CommandListType StageAlignmentPoint = mergeCommandLists(createDotArcs(SpotSize, LaserSpotSize, CartesianCoordinates()),
                                                            createCircle(CircleRadius, 0, CartesianCoordinates()));

    StageAlignmentPoint.push_back(getHomeJump());
    return writeJob(SLHandle, JobID, StageAlignmentPoint);
}

uint32_t writeStageVerificationGrid(size_t SLHandle, size_t& JobID, const CartesianCoordinates& Start, const CartesianCoordinates& End, const CartesianCoordinates& StepSize)
{
    const double CrossSize = 1;
    CommandListType StageVerificationGrid = mergeCommandLists(
    {
        createGrid(Start, End, StepSize, 1, 1,10000, [&CrossSize](CartesianCoordinates Center, int Direction, int, double)
        {
            return createLine(CartesianCoordinates(Center.X() - CrossSize / 2, Center.Y()), CartesianCoordinates(Center.X() + CrossSize / 2, Center.Y()), (Direction < 0));
        }),
        createGrid(End, Start, CartesianCoordinates( -StepSize.X(), -StepSize.Y() ), 0, 1,10000, [&CrossSize](CartesianCoordinates Center, int Direction, int, double)
        {
            return createLine(CartesianCoordinates(Center.X(), Center.Y() - CrossSize / 2), CartesianCoordinates(Center.X(), Center.Y() + CrossSize / 2), (Direction > 0));
        })
    });

    StageVerificationGrid.push_back(getHomeJump());
    return writeJob(SLHandle, JobID, StageVerificationGrid);
}

uint32_t writeScannerVerificationGrid(size_t SLHandle, size_t& JobID, const CartesianCoordinates& Start, const CartesianCoordinates& End, const CartesianCoordinates& StepSize)
{
    double CircleRad1 = 0.5;
    double CircleRad2 = 1;
    CommandListType ScannerVerificationGrid = createGrid(Start, End, StepSize, 1, 1, 10000, [&CircleRad1, &CircleRad2](CartesianCoordinates Center, int Direction, int, double)
    {
        (void)Direction;
        return mergeCommandLists(createCircle(CircleRad1, 0, Center), createCircle(CircleRad2, 0, Center));
    });
    ScannerVerificationGrid.push_back(getHomeJump());
    return writeJob(SLHandle, JobID, ScannerVerificationGrid);
}


uint32_t writeCombinedAccuracyJob(size_t SLHandle, size_t& JobID, const CartesianCoordinates& Start, const CartesianCoordinates& End, const CartesianCoordinates& StepSize, double FoV, const Geometries& Geometry, bool UseStageSkyWriting, double vStage, double Bandwidth, double ScalingFactor)
{
    uint32_t RetVal = 0;
    size_t PointsPerTile = static_cast<size_t>(std::floor(FoV / StepSize.Y()) + 1.);
    const double TileSize = (PointsPerTile - 1) * StepSize.Y();
    CartesianCoordinates Step = StepSize;
    Step.Y() += TileSize;

    CommandListType CombinedAccuracy;

    double PrevJumpSpeed = 0;

    TrajectoryConfiguration TrajConfig;
    RetVal |= getTrajectoryConfig(SLHandle, TrajConfig);

    if (0 == RetVal && TrajConfig.Content != nullptr)
    {
        PrevJumpSpeed = TrajConfig.Content->MarkConfig.JumpSpeed;
    }
    else
    {
        return RetVal;
    }
    slsc_OperationMode PreviousMode;
    RetVal |= getMode(SLHandle, PreviousMode);
    RetVal |= setMode(SLHandle, slsc_OperationMode::slsc_OperationMode_ScannerAndStage);

    auto MarkingFigure = std::function<CommandListType(CartesianCoordinates, int, int, double)>([TileSize, PointsPerTile, Geometry, &TrajConfig](CartesianCoordinates Center, int Direction, int BiDirectionality, double CutOff)
    {
        (void)Direction;
        double StepSizeY = TileSize / (PointsPerTile - 1.);
        double TileSizeInt = TileSize;
        size_t PointsPerTileInt = PointsPerTile;

        CommandListType ReturnCommandList;

        if ((CutOff > -EPSILON) && (CutOff < TileSize))
        {
            TileSizeInt = CutOff;
            PointsPerTileInt = static_cast<size_t>(std::round(TileSizeInt / StepSizeY) + 1.);
            ReturnCommandList.push_back(createChangeSpeedCommand(TrajConfig.Content->MarkConfig.JumpSpeed * PointsPerTileInt / PointsPerTile,
                                                                 TrajConfig.Content->MarkConfig.MarkSpeed * PointsPerTileInt / PointsPerTile));
        }

        switch (Geometry)
        {
            case Geometries::CIRCLE:
            {
                if (BiDirectionality < 0)
                {
                    for (size_t i = PointsPerTileInt; i > 0; --i)
                    {
                        appendCommandList(ReturnCommandList,
                                          createCircle(1.2, 0, CartesianCoordinates(Center.X(), Center.Y() + (i - 1) * StepSizeY)));
                    }
                }
                else
                {
                    for (size_t i = 0; i < PointsPerTileInt; ++i)
                    {
                        appendCommandList(ReturnCommandList,
                                          createCircle(1.2, 0, CartesianCoordinates(Center.X(), Center.Y() + i * StepSizeY)));
                    }
                }
                break;
            }
            case Geometries::TWO_CIRCLES:
            {
                if (BiDirectionality < 0)
                {
                    for (size_t i = PointsPerTileInt; i > 0; --i)
                    {
                        appendCommandList(ReturnCommandList,
                                          createMultipleCircles(0.25, 0.1, 0.15, 0,
                                                                CartesianCoordinates(Center.X(), Center.Y() + (i - 1) *  StepSizeY)));
                    }
                }
                else
                {
                    for (size_t i = 0; i < PointsPerTileInt; ++i)
                    {
                        appendCommandList(ReturnCommandList,
                                          createMultipleCircles(0.25, 0.1, 0.15, 0,
                                                                CartesianCoordinates(Center.X(), Center.Y() + i *  StepSizeY)));
                    }
                }

                break;
            }
            case Geometries::CROSS:
            {
                if (BiDirectionality < 0)
                {
                    for (size_t i = PointsPerTileInt; i > 0; --i)
                    {
                        appendCommandList(ReturnCommandList,
                                          createCross(2,
                                                      CartesianCoordinates(Center.X(), Center.Y() + (i - 1) *  StepSizeY)));
                    }
                }
                else
                {
                    for (size_t i = 0; i < PointsPerTileInt; ++i)
                    {
                        appendCommandList(ReturnCommandList,
                                          createCross(2,
                                                      CartesianCoordinates(Center.X(), Center.Y() + i *  StepSizeY)));
                    }
                }

                break;
            }
            case Geometries::DOT:
            {
                if (BiDirectionality < 0)
                {
                    for (size_t i = PointsPerTileInt; i > 0; --i)
                    {
                        appendCommandList(ReturnCommandList,
                                          createDotArcs(0.25, 0.05,
                                                        CartesianCoordinates(Center.X(), Center.Y() + (i - 1) * StepSizeY)));
                    }
                }
                else
                {
                    for (size_t i = 0; i < PointsPerTileInt; ++i)
                    {
                        appendCommandList(ReturnCommandList,
                                          createDotArcs(0.25, 0.05,
                                                        CartesianCoordinates(Center.X(), Center.Y() + i * StepSizeY)));
                    }
                }

                break;
            }
            case Geometries::NONE:
            default:
                break;
        }
        if ((CutOff > 0.0) && (CutOff < TileSize))
        {
            TileSizeInt = CutOff;
            // here nor std::floor or std::ceil or std::round=
            PointsPerTileInt = static_cast<size_t>(TileSizeInt / StepSizeY + 1.);
        }
        ReturnCommandList.push_back(createChangeSpeedCommand(TrajConfig.Content->MarkConfig.JumpSpeed, TrajConfig.Content->MarkConfig.MarkSpeed));
        return ReturnCommandList;
    });

    if (UseStageSkyWriting)
    {
        double MinWaitTime = TrajConfig.Content->MarkConfig.LaserMinOffTime
                             + (TrajConfig.Content->MarkConfig.LaserPreTriggerTime > 0 ? TrajConfig.Content->MarkConfig.LaserPreTriggerTime : 0);
        CombinedAccuracy = createGridWithStageSkyWriting(Start, End, Step, 1, FoV, Bandwidth, vStage, ScalingFactor, PrevJumpSpeed, MinWaitTime, MarkingFigure);
    }
    else
    {
        CombinedAccuracy = createGrid(Start, End, Step, 1, 0, FoV, MarkingFigure);
    }
    CombinedAccuracy.push_back(Command2D());
    RetVal |= setTrajectoryConfig(SLHandle, TrajConfig);

    RetVal |= setMode(SLHandle, PreviousMode);

    RetVal |= writeJob(SLHandle, JobID, CombinedAccuracy);
    return RetVal;
}

uint32_t executeReferenceRun(size_t SLHandle, double ScannerWidth, double StageWidth, double StageSpeed)
{
    CartesianCoordinates Center;
    CartesianCoordinates TargetScanner1{ -ScannerWidth,ScannerWidth };
    CartesianCoordinates TargetScanner2{ -ScannerWidth,-ScannerWidth };
    CartesianCoordinates TargetScanner3{ ScannerWidth,-ScannerWidth };
    CartesianCoordinates TargetScanner4{ ScannerWidth,ScannerWidth };
    CartesianCoordinates TargetStage1{ StageWidth,StageWidth };
    CartesianCoordinates TargetStage2{ -StageWidth,StageWidth };
    CartesianCoordinates TargetStage3{ -StageWidth,-StageWidth };
    CartesianCoordinates TargetStage4{ StageWidth,-StageWidth };

    uint32_t RetVal = executeStageMovement(SLHandle, Center, StageSpeed);

    RetVal |= setToManualPositioningMode(SLHandle);

    // run a single time
    {
        RetVal |= moveStage(SLHandle, TargetStage1, StageSpeed / 2);
        RetVal |= moveStage(SLHandle, TargetStage2, StageSpeed);
        RetVal |= moveStage(SLHandle, TargetStage3, StageSpeed);
        RetVal |= moveStage(SLHandle, TargetStage4, StageSpeed);
        RetVal |= moveStage(SLHandle, TargetStage1, StageSpeed);
    }

    RetVal |= moveStage(SLHandle, Center, StageSpeed / 2);

    RetVal |= moveScanner(SLHandle, TargetScanner1);
    RetVal |= laserOn(SLHandle);
    std::this_thread::sleep_for(std::chrono::milliseconds(200));

    for (size_t i = 0; i < 3; ++i)
    {
        RetVal |= moveScanner(SLHandle, TargetScanner2);
        RetVal |= laserOn(SLHandle);
        std::this_thread::sleep_for(std::chrono::milliseconds(200));

        RetVal |= moveScanner(SLHandle, TargetScanner3);
        RetVal |= laserOn(SLHandle);
        std::this_thread::sleep_for(std::chrono::milliseconds(200));

        RetVal |= moveScanner(SLHandle, TargetScanner4);
        RetVal |= laserOn(SLHandle);
        std::this_thread::sleep_for(std::chrono::milliseconds(200));

        RetVal |= moveScanner(SLHandle, TargetScanner1);
        RetVal |= laserOn(SLHandle);
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
    }
    RetVal |= laserOff(SLHandle);
    RetVal |= moveScanner(SLHandle, Center);
    RetVal |= setTosyncAXISMode(SLHandle);
    return RetVal;
}

uint32_t executeTestMarking(size_t SLHandle, double ScalingFactor, bool AutoStart)
{
    uint32_t RetVal = 0;
    size_t JobID = 0;

    auto ListFilling = std::async(std::launch::async, [SLHandle, &JobID, ScalingFactor]()
    {
        return writeTestMarking(SLHandle, JobID, 0.5 * ScalingFactor);
    });
    RetVal |= startJob(SLHandle, AutoStart);
    RetVal |= ListFilling.get();
    if (RetVal == 0)
    {
        RetVal = printJobCharacteristics(SLHandle, JobID);
    }
    return RetVal;
}

uint32_t executeCalibrationCheck(size_t SLHandle, double GridSize, int NumberOfGridPoints, double StageSpeed, bool AutoStart)
{
    const CartesianCoordinates Start(-GridSize / 2, -GridSize / 2);
    const CartesianCoordinates End(GridSize / 2, GridSize / 2);
    const CartesianCoordinates StepSize(GridSize / (NumberOfGridPoints - 1), GridSize / (NumberOfGridPoints - 1));

    TrajectoryConfiguration TrajConfig;
    uint32_t RetVal = getTrajectoryConfig(SLHandle, TrajConfig);

    if (0 == RetVal && TrajConfig.Content != nullptr)
    {
        slsc_OperationMode PreviousMode;
        RetVal |= getMode(SLHandle, PreviousMode);

        // Markingpattern #5 in Stage Only mode
        RetVal |= setMode(SLHandle, slsc_OperationMode::slsc_OperationMode_StageOnly);
        RetVal |= cfgSetJumpSpeed(SLHandle, StageSpeed);
        RetVal |= cfgSetMarkSpeed(SLHandle, StageSpeed);

        size_t JobID = 0;
        auto ListFillingStage = std::async(std::launch::async, [SLHandle, &JobID, Start, End, StepSize]()
        {
            return writeStageVerificationGrid(SLHandle, JobID, Start, End, StepSize);
        });
        RetVal |= startJob(SLHandle, AutoStart);
        RetVal |= ListFillingStage.get();
        // Markingpattern #4 in Scanner Only mode
        RetVal |= setTrajectoryConfig(SLHandle, TrajConfig);
        RetVal |= setMode(SLHandle, slsc_OperationMode::slsc_OperationMode_ScannerOnly);

        auto ListFillingScanner = std::async(std::launch::async, [SLHandle, &JobID, Start, End, StepSize]()
        {
            return writeScannerVerificationGrid(SLHandle, JobID, Start, End, StepSize);
        });
        RetVal |= startJob(SLHandle, AutoStart);
        RetVal |= ListFillingScanner.get();

        RetVal |= setMode(SLHandle, PreviousMode);
    }
    return RetVal;
}

uint32_t executeScannerCalibrationJob(size_t SLHandle, double GridSize, int NumberOfGridPoints, double StageSpeed, bool AutoStart)
{
    const std::string ModuleName = "Spiral.slm";
    uint32_t RetVal = createSpiralModule(SLHandle, ModuleName.c_str());

    const CartesianCoordinates Start(-GridSize / 2, -GridSize / 2);
    const CartesianCoordinates End(GridSize / 2, GridSize / 2);
    const CartesianCoordinates StepSize(GridSize / (NumberOfGridPoints - 1), GridSize / (NumberOfGridPoints - 1));

    const CartesianCoordinates PointLocation(50, 0);

    slsc_OperationMode PreviousMode;
    RetVal |= getMode(SLHandle, PreviousMode);

    std::cout << "The stage will be moved to center position! Keep clear of the stage!" << std::endl;

    // Driving stage to the center position
    RetVal |= executeStageMovement(SLHandle, CartesianCoordinates(), StageSpeed);

    // Markingpattern #2 in Scanner Only mode
    RetVal |= setMode(SLHandle, slsc_OperationMode::slsc_OperationMode_ScannerOnly);
    size_t JobID = 0;
    auto ListFillingScanner1 = std::async(std::launch::async, [&]()
    {
        return writeScannerCalibrationGrid(SLHandle, JobID, Start, End, StepSize, ModuleName.c_str());
    });
    RetVal |= startJob(SLHandle, AutoStart);
    RetVal |= ListFillingScanner1.get();
    // Driving stage to a shifted position
    RetVal |= executeStageMovement(SLHandle, PointLocation, StageSpeed);

    // Markingpattern #3 in Scanner Only mode
    RetVal |= setMode(SLHandle, slsc_OperationMode::slsc_OperationMode_ScannerOnly);
    auto ListFillingScanner2 = std::async(std::launch::async, [&]()
    {
        return writeStageAlignmentPoint(SLHandle, JobID);
    });
    RetVal |= startJob(SLHandle, AutoStart);
    RetVal |= ListFillingScanner2.get();
    RetVal |= setMode(SLHandle, PreviousMode);

    RetVal |= executeStageMovement(SLHandle, CartesianCoordinates(), StageSpeed);
    return RetVal;
}

uint32_t executeStageCalibrationJob(size_t SLHandle, double GridSize, int NumberOfGridPoints, double StageSpeed, bool AutoStart)
{
    const CartesianCoordinates Start(-GridSize / 2, -GridSize / 2);
    const CartesianCoordinates End(GridSize / 2, GridSize / 2);
    const CartesianCoordinates StepSize(GridSize / (NumberOfGridPoints - 1), GridSize / (NumberOfGridPoints - 1));

    slsc_OperationMode PreviousMode;
    uint32_t RetVal = getMode(SLHandle, PreviousMode);
    RetVal |= setMode(SLHandle, slsc_OperationMode::slsc_OperationMode_ScannerOnly);

    CartesianCoordinates Position = Start;
    int Direction = 1;

    std::cout << "The stage will be moved! Keep clear of the stage!" << std::endl;

    while (((Position.Y() >= Start.Y() - EPSILON) && (Position.Y() <= End.Y() + EPSILON)) || ((Position.Y() <= Start.Y() + EPSILON) && (Position.Y() >= End.Y() - EPSILON)))
    {
        changeDirection(Direction, Position.X(), Start.X(), End.X());

        while (((Position.X() >= Start.X() - EPSILON) && (Position.X() <= End.X() + EPSILON)) || ((Position.X() <= Start.X() + EPSILON) && (Position.X() >= End.X() - EPSILON)))
        {
            RetVal |= executeStageMovement(SLHandle, Position, StageSpeed);

            const auto ListFilling = std::async(std::launch::async, [&]()
            {
                CommandListType Job = createDotArcs(0.5, 0.05, CartesianCoordinates());
                size_t JobID = 0;
                RetVal |= writeJob(SLHandle, JobID, Job);
            });
            RetVal |= startJob(SLHandle, AutoStart);
            Position.X() += Direction*StepSize.X();
        }
        Position.Y() += StepSize.Y();
    }

    RetVal |= setMode(SLHandle, PreviousMode);
    RetVal |= executeStageMovement(SLHandle, CartesianCoordinates(), StageSpeed);
    return RetVal;
}


uint32_t executeLaserDelayCheck(size_t SLHandle, double VScanner, double StartSwitchOffset, double IncrementSwitchOffset, double StartPreTrigger, double IncrementPreTrigger, CartesianCoordinates GlobalOffset, bool AutoStart)
{
    bool JobStart = false;
    const double Size = 1;
    const double Gap = 0.1;

    std::function<CommandListType(CartesianCoordinates)> MarkingFigure = [Gap, Size](CartesianCoordinates Center)
    {
        return CommandListType
        {
            createJumpCommand(Center.X() - Size / 2,            Center.Y() - Size),
            createMarkCommand(Center.X() - Gap / 2,             Center.Y() -  Size),
            createJumpCommand(Center.X() + Gap / 2,             Center.Y() -  Size),
            createMarkCommand(Center.X() + Size / 2,            Center.Y() -  Size),
            createJumpCommand(Center.X() + 0,                   Center.Y() -  Size),
            createMarkCommand(Center.X() + 0,                   Center.Y() +  Size),
            createJumpCommand(Center.X() + Size / 2,            Center.Y() + Size),
            createMarkCommand(Center.X() + Gap / 2,             Center.Y() + Size),
            createJumpCommand(Center.X() - Gap / 2,             Center.Y() + Size),
            createMarkCommand(Center.X() - Size / 2,            Center.Y() + Size),
            createJumpCommand(Center.X() - Size / 2 - 0.001,    Center.Y() +  Size),
        };
    };

    const double StoUSConversion = 1. / 1000000.;

    slsc_OperationMode PreviousMode;
    uint32_t RetVal = getMode(SLHandle, PreviousMode);
    TrajectoryConfiguration TrajConfig;
    RetVal |= getTrajectoryConfig(SLHandle, TrajConfig);
    TrajectoryConfiguration TrajConfigInitial;
    RetVal |= getTrajectoryConfig(SLHandle, TrajConfigInitial);
    if (0 != RetVal && TrajConfig.Content != nullptr)
    {
        return RetVal;
    }

    RetVal |= executeStageMovement(SLHandle, GlobalOffset, 100);
    RetVal |= applyTransformation(SLHandle, CartesianCoordinates());

    RetVal |= setMode(SLHandle, slsc_OperationMode::slsc_OperationMode_ScannerOnly);

    TrajConfig.Content->MarkConfig.JumpSpeed = VScanner;
    TrajConfig.Content->MarkConfig.MarkSpeed = VScanner;

    const double GridFactor = 2.5;
    const int NumberOfGridPositions = 11;
    CartesianCoordinates OffsetInitial = CartesianCoordinates(-(NumberOfGridPositions - 1.) / 2 * GridFactor * Size, -(NumberOfGridPositions - 1.) / 2 * GridFactor * Size);
    CartesianCoordinates Offset = OffsetInitial;
    int GridCounter = 0;

    for (int i = 0; i < NumberOfGridPositions; ++i)
    {
        TrajConfig.Content->MarkConfig.LaserSwitchOffsetTime = (i * IncrementSwitchOffset * StoUSConversion + StartSwitchOffset * StoUSConversion);
        Offset.X() = GridFactor * Size * i + OffsetInitial.X();
        Offset.Y() = OffsetInitial.Y();

        for (int j = 0; j < NumberOfGridPositions; ++j)
        {
            TrajConfig.Content->MarkConfig.LaserPreTriggerTime = (j * IncrementPreTrigger * StoUSConversion + StartPreTrigger* StoUSConversion);
            Offset.Y() = (GridFactor * Size * j + OffsetInitial.Y());
            RetVal |= setTrajectoryConfig(SLHandle, TrajConfig);

            CommandListType Job = MarkingFigure(Offset);
            size_t JobID = 0;
            RetVal |= writeJob(SLHandle, JobID, Job);
            GridCounter++;
            RetVal |= startJob(SLHandle, JobStart);
        }
    }

    RetVal |= setTrajectoryConfig(SLHandle, TrajConfigInitial);
    RetVal |= setMode(SLHandle, PreviousMode);
    RetVal |= applyTransformation(SLHandle, GlobalOffset);
    return RetVal;
}

uint32_t executeSystemDelayCheck(size_t SLHandle, double VStage, double RStage, CartesianCoordinates GlobalOffset, bool AutoStart)
{
    const double v_aLimit = sqrt(RStage / 2. * 0.42 * VStage * 10);
    VStage = (VStage < v_aLimit ? VStage : v_aLimit);
    const double JumpSpeed = 4 * VStage;
    const double MarkSpeed = JumpSpeed;

    const double LineLength = 3;

    TrajectoryConfiguration TrajConfig;
    uint32_t RetVal = getTrajectoryConfig(SLHandle, TrajConfig);
    TrajectoryConfiguration TrajConfigInitial;
    RetVal |= getTrajectoryConfig(SLHandle, TrajConfigInitial);
    if (0 != RetVal || TrajConfig.Content == nullptr)
    {
        return RetVal;
    }

    slsc_OperationMode PreviousMode;
    RetVal |= getMode(SLHandle, PreviousMode);
    RetVal |= setMode(SLHandle, slsc_OperationMode::slsc_OperationMode_ScannerAndStage);

    TrajConfig.Content->MarkConfig.JumpSpeed = JumpSpeed;
    TrajConfig.Content->MarkConfig.MarkSpeed = MarkSpeed;

    RetVal |= setTrajectoryConfig(SLHandle, TrajConfig);

    std::function<CommandListType(CartesianCoordinates, double)> Arrow = [LineLength, JumpSpeed, MarkSpeed](CartesianCoordinates Center, double DirectionAngle)
    {
        (void)DirectionAngle;
        return CommandListType(
        {
            createJumpCommand(Center.X() + -5., Center.Y() + 0. + 2. * LineLength),
            createMarkCommand(Center.X() + 5.,  Center.Y() + 0. + 2. * LineLength),
            createJumpCommand(Center.X() + 3.,  Center.Y() + 2. + 2. * LineLength),
            createMarkCommand(Center.X() + 5.,  Center.Y() + 0. + 2. * LineLength),
            createMarkCommand(Center.X() + 3.,  Center.Y() + -2. + 2. * LineLength),
            createJumpCommand(Center.X() + 0.,  Center.Y() + 0. + 2. * LineLength),
        });
    };

    std::function<CommandListType(CartesianCoordinates, double)> LineBlock = [RStage, VStage, LineLength, JumpSpeed, MarkSpeed, &TrajConfig](CartesianCoordinates Center, double DirectionAngle)
    {
        (void)DirectionAngle;
        const uint32_t TotalNumberOfLines = 20;
        const double Increment = 1;

        CommandListType ReturnCommandList;
        ReturnCommandList.push_back(createChangeSpeedCommand(VStage, MarkSpeed));
        ReturnCommandList.push_back(createJumpCommand((Center.X() - RStage), (Center.Y() + 0)));
        ReturnCommandList.push_back(createWaitCommand(TrajConfig.Content->MarkConfig.LaserMinOffTime + (TrajConfig.Content->MarkConfig.LaserPreTriggerTime > 0 ? TrajConfig.Content->MarkConfig.LaserPreTriggerTime : 0)));
        ReturnCommandList.push_back(createJumpCommand((Center.X() - RStage), (Center.Y() + LineLength)));
        ReturnCommandList.push_back(createWaitCommand(TrajConfig.Content->MarkConfig.LaserMinOffTime + (TrajConfig.Content->MarkConfig.LaserPreTriggerTime > 0 ? TrajConfig.Content->MarkConfig.LaserPreTriggerTime : 0)));
        ReturnCommandList.push_back(createJumpCommand((Center.X() - (TotalNumberOfLines / 2.)*Increment), (Center.Y() + LineLength)));
        ReturnCommandList.push_back(createChangeSpeedCommand(JumpSpeed, MarkSpeed));

        for (int LineNumber = 0; LineNumber <= TotalNumberOfLines; LineNumber+=2)
        {
            ReturnCommandList.push_back(createJumpCommand((Center.X() + (LineNumber - TotalNumberOfLines / 2.)*Increment), (Center.Y() + LineLength)));
            ReturnCommandList.push_back(createMarkCommand((Center.X() + (LineNumber - TotalNumberOfLines / 2.)*Increment), (Center.Y() + 0.1)  ));
            if (LineNumber + 1 <= TotalNumberOfLines)
            {
                ReturnCommandList.push_back(createJumpCommand((Center.X() + (LineNumber + 1 - TotalNumberOfLines / 2.)*Increment), (Center.Y() + 0.1)));
                ReturnCommandList.push_back(createMarkCommand((Center.X() + (LineNumber + 1 - TotalNumberOfLines / 2.)*Increment), (Center.Y() + LineLength)));
            }
        }
        ReturnCommandList.push_back(createChangeSpeedCommand(VStage, MarkSpeed));
        ReturnCommandList.push_back(createJumpCommand((Center.X() + RStage), (Center.Y() + LineLength)));
        ReturnCommandList.push_back(createWaitCommand(TrajConfig.Content->MarkConfig.LaserMinOffTime + (TrajConfig.Content->MarkConfig.LaserPreTriggerTime > 0 ? TrajConfig.Content->MarkConfig.LaserPreTriggerTime : 0)));
        ReturnCommandList.push_back(createJumpCommand((Center.X() + RStage), (Center.Y()  - LineLength)));
        ReturnCommandList.push_back(createWaitCommand(TrajConfig.Content->MarkConfig.LaserMinOffTime + (TrajConfig.Content->MarkConfig.LaserPreTriggerTime > 0 ? TrajConfig.Content->MarkConfig.LaserPreTriggerTime : 0)));
        ReturnCommandList.push_back(createJumpCommand((Center.X() + (TotalNumberOfLines / 2.)*Increment), (Center.Y() - LineLength)));
        ReturnCommandList.push_back(createChangeSpeedCommand(JumpSpeed, MarkSpeed));

        for (int LineNumber = TotalNumberOfLines; LineNumber >= 0; LineNumber -= 2)
        {
            ReturnCommandList.push_back(createJumpCommand((Center.X() + (LineNumber - TotalNumberOfLines / 2.)*Increment), (Center.Y() - LineLength)));
            ReturnCommandList.push_back(createMarkCommand((Center.X() + (LineNumber - TotalNumberOfLines / 2.)*Increment), (Center.Y() - 0.1)));
            if (LineNumber - 1 >= 0)
            {
                ReturnCommandList.push_back(createJumpCommand((Center.X() + (LineNumber - 1 - TotalNumberOfLines / 2.)*Increment), (Center.Y() - 0.1)));
                ReturnCommandList.push_back(createMarkCommand((Center.X() + (LineNumber - 1 - TotalNumberOfLines / 2.)*Increment), (Center.Y() - LineLength)));
            }
        }

        ReturnCommandList.push_back(createChangeSpeedCommand(VStage, MarkSpeed));
        ReturnCommandList.push_back(createJumpCommand((Center.X() - RStage), (Center.Y() - LineLength)));
        ReturnCommandList.push_back(createWaitCommand(TrajConfig.Content->MarkConfig.LaserMinOffTime + (TrajConfig.Content->MarkConfig.LaserPreTriggerTime > 0 ? TrajConfig.Content->MarkConfig.LaserPreTriggerTime : 0)));
        ReturnCommandList.push_back(createJumpCommand((Center.X() ), (Center.Y())));

        return ReturnCommandList;
    };

    const double Offsetsize = 5 * LineLength;
    CartesianCoordinates Offset(0, -Offsetsize);
    double Orientation = 0; // in degree

    for (int i = 0; i < 4; ++i)
    {
        RetVal |= applyTransformation(SLHandle, Orientation, Offset + GlobalOffset);
        size_t JobID = 0;
        RetVal |= writeJob(SLHandle, JobID, Arrow(CartesianCoordinates(), Orientation));
        RetVal |= startJob(SLHandle, AutoStart);
        Orientation = std::fmod((i + 1) * 90, 360);
        changeOffset(Offsetsize, Orientation, Offset);
    }

    for (int i = 0; i < 4; ++i)
    {
        RetVal |= applyTransformation(SLHandle, Orientation, Offset + GlobalOffset);
        size_t JobID = 0;
        RetVal |= writeJob(SLHandle, JobID, LineBlock(CartesianCoordinates(), Orientation));
        RetVal |= startJob(SLHandle, AutoStart);
        Orientation = std::fmod((i + 1) * 90, 360);
        changeOffset(Offsetsize, Orientation, Offset);
    }

    RetVal |= setTrajectoryConfig(SLHandle, TrajConfigInitial);
    RetVal |= setMode(SLHandle, PreviousMode);
    return RetVal;
}

// Utility functions

uint32_t checkForErrors(size_t SLHandle)
{
    uint32_t RetVal = 0;
    if (0 == SLHandle)
    {
        std::cout << "Initialize first." << std::endl;
        return RetVal;
    }

    std::vector<std::pair<uint64_t, std::string>> ErrorList;
    RetVal |= getErrors(SLHandle, ErrorList);

    for (const auto& Error : ErrorList)
    {
        std::cout << "Error with error code: " << std::hex << Error.first << std::dec << std::endl;
        std::cout << "Error text: " << Error.second << std::endl;
    }
    return RetVal;
}


uint32_t executeStageMovement(size_t SLHandle, const CartesianCoordinates& Position, double StageSpeed)
{
    uint32_t RetVal = setToManualPositioningMode(SLHandle);
    RetVal |= moveStage(SLHandle, Position, StageSpeed);
    RetVal |= setTosyncAXISMode(SLHandle);
    return RetVal;
}

uint32_t executeCombinedAccuracyJob(size_t SLHandle,
                                    double GridSize,
                                    int NumberOfGridPoints,
                                    double FoV,
                                    const Geometries& Geometry,
                                    bool UseStageSkyWriting,
                                    double vStage,
                                    double Bandwidth,
                                    double ScalingFactor,
                                    bool AutoStart)
{

    size_t JobID = 0;
    auto ListFilling = std::async(std::launch::async,
                                  [&]()
    {
        return writeCombinedAccuracyJob(SLHandle, JobID,
                                        CartesianCoordinates(-GridSize / 2, -GridSize / 2),
                                        CartesianCoordinates(GridSize / 2, GridSize / 2),
                                        CartesianCoordinates(GridSize / (NumberOfGridPoints - 1), GridSize / (NumberOfGridPoints - 1)),
                                        FoV, Geometry, UseStageSkyWriting, vStage, Bandwidth, ScalingFactor);
    });
    uint32_t RetVal = startJob(SLHandle, AutoStart);
    RetVal |= ListFilling.get();
    RetVal |= printJobCharacteristics(SLHandle, JobID, FoV);
    return RetVal;
}

uint32_t createSpiralModule(size_t SLHandle, const char* ModuleName)
{
    size_t ModuleHandle = 0;
    uint32_t RetVal = initializeCopy(SLHandle, ModuleHandle);

    RetVal |= setMode(ModuleHandle, slsc_OperationMode_ScannerOnly);

    size_t JobID = 0;
    const double SpotSize = 1;
    const double LaserSpotSize = 0.05;

    auto ModuleJob = std::async(std::launch::async, [&]()
    {
        return writeModule(ModuleHandle, JobID, CartesianCoordinates(0.0, 0.0), createDotArcs(SpotSize, LaserSpotSize, CartesianCoordinates(0.0, 0.0)), ModuleName);
    });

    bool StartImmediately = true;
    RetVal |= startJob(ModuleHandle, StartImmediately);
    RetVal |= ModuleJob.get();
    RetVal |= deleteControl(ModuleHandle);
    return RetVal;
}
