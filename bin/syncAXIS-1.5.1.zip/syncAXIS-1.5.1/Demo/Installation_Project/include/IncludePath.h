/*
***************************************************************************
File: IncludePath.h(.in)

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a 
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#pragma once

#include <string>

const std::string AdditionalConfigFileDir = "";
