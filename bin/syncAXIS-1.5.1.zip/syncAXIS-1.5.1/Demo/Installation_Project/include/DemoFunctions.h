/*
***************************************************************************
File: DemoFunctions.h

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#pragma once

#include "InputTypes.h"

#include <iostream>
#include <map>
#include <string>
#include <iomanip>
#include <vector>
#include <functional>

//! \brief Each operation type corresponds to an possible user input. E.g. some markings, syncAXIS Control initialisation,...
enum class OperationType : uint32_t
{
    EXIT                = 0,
    INIT                = 1,
    CHECK_LASER_FIRING  = 2,
    REFERENCE_RUN       = 3,
    TEST_MARKING        = 4,
    SCANNER_CALI        = 5,
    STAGE_CALI          = 6,
    COMBINED_ACCURACY   = 7,
    CHECK_LASERDELAYS   = 8,
    CHECK_CALIBRATIONS  = 9,
    CHECK_SYSTEMDELAYS  = 10,
    CHANGE_SETTINGS     = 11,
    DELETE_INSTANCE     = 12,
    CHECK_FOR_ERRORS    = 13,
};

//! \brief Each setting type corresponds to a setting that can be changed with OperationType::CHANGE_SETTINGS.
enum class SettingsType : uint32_t
{
    EXIT                = 0,
    OPMODE              = 1,
    SPEEDS              = 2,
    OFFSET              = 3,
};

//! \brief Each geometry corresponds to a "point"-like type for some markings.
enum class Geometries : uint32_t
{
    NONE        = 0,
    CIRCLE      = 1,
    TWO_CIRCLES = 2,
    CROSS       = 3,
    DOT         = 4,
};

struct StringDuplet
{
    std::string Description;
    std::string Brief;
};

const std::map <OperationType, StringDuplet>& getOperationCaseDescriptions();
StringDuplet getOperationCaseDescriptions(OperationType Input);
const std::map <std::string, OperationType>& getOperationCases();
OperationType getOperationCases(const std::string& Input);
const std::map <SettingsType, StringDuplet>& getChangeSettingCaseDescriptions();
StringDuplet getChangeSettingCaseDescriptions(SettingsType Input);
const std::map <std::string, SettingsType>& getChangeSettingCases();
SettingsType getChangeSettingCases(const std::string& Input);
const std::map <Geometries, StringDuplet>& getGeometryCaseDescriptions();
StringDuplet getGeometryCaseDescriptions(Geometries Input);
const std::map <std::string, Geometries>& getGeometryCases();
Geometries getGeometryCases(const std::string& Input);

void printSeparationLine();

bool expectPositiveDouble(double Input);
bool expectDoubleBetween0And1(double Input);
bool expectAnyDouble(double Input);

bool expectOddIntGreater1(int Input);
bool expectNonNegativeInt(int Input);
bool expectAnyInt(int Input);

bool tryReadingBool();
int tryReadingInt(std::function<bool(int)> ValidationFunc);
double tryReadingDouble(std::function<bool(double)> ValidationFunc);

size_t readConfigFileIndex(const std::vector<std::string>& ConfigFilePaths);
double readScalingFactor();

Geometries readGeometry();

uint32_t checkForErrors(size_t SLHandle);
uint32_t printJobCharacteristics(size_t SLHandle, size_t JobID, double FoV = -1);
bool checkForSuccessfulInit(bool SuccessfulInit, uint32_t RetVal);
void changeOffset(double Offsetsize, double Angle, CartesianCoordinates& Offset);
uint32_t changeOperationMode(size_t SLHandle, CartesianCoordinates& Offset, CartesianCoordinates& PrevOffset);
uint32_t changeSpeed(size_t SLHandle);
void changeConfigFilePath(std::vector<std::string>& ConfigFilePathes, size_t& ConfigFileIndex);


template<typename T>
void printOptions(const std::map<T, StringDuplet>& CaseDescriptions)
{
    std::cout << "Please choose one of the following options:"<< std::endl;
    for (const auto& Case : CaseDescriptions)
    {
        std::cout << "Enter " << static_cast<uint32_t>(Case.first) << ": \"" << Case.second.Description << "\". (" << Case.second.Brief << ")" << std::endl;
    }
    std::cout << "Please enter: ";
    return;
}
