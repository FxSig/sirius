/*
***************************************************************************
File: syncAXISControl.h

***************************************************************************

Manufacturer

SCANLAB GmbH
Siemensstr. 2a
82178 Puchheim
Germany

Tel. + 49 (89) 800 746-0
Fax: + 49 (89) 800 746-199

info@scanlab.de
www.scanlab.de

***************************************************************************
*/
#pragma once

#include "MarkingPatterns.h"
#include "syncAXISDefinitions.h"
#include <map>

struct TrajectoryConfiguration
{
    TrajectoryConfiguration();
    TrajectoryConfiguration(TrajectoryConfiguration&& In) noexcept;
    TrajectoryConfiguration& operator=(TrajectoryConfiguration&& In)& noexcept;

    ~TrajectoryConfiguration() noexcept;

    TrajectoryConfiguration(const TrajectoryConfiguration& In) = delete;
    TrajectoryConfiguration& operator=(const TrajectoryConfiguration& In)& = delete;

    slsc_TrajectoryConfig* Content;
    bool CreatedBySyncAxisDll;
};

uint32_t initializeControl(size_t& SLHandle, const std::string& ConfigFile);
uint32_t deleteControl(size_t& SLHandle);
uint32_t initializeCopy(size_t OrigHandle, size_t& CopyHandle);
uint32_t applyTransformation(size_t SLHandle, const TransformationMatrix& Transformation, const CartesianCoordinates& Offset);
uint32_t applyTransformation(size_t SLHandle, double Rotation, const CartesianCoordinates& Offset);
uint32_t applyTransformation(size_t SLHandle, const CartesianCoordinates& Offset);

uint32_t setMode(size_t SLHandle, slsc_OperationMode Mode);
uint32_t getMode(size_t SLHandle, slsc_OperationMode& Mode);

uint32_t getErrors(size_t SLHandle, std::vector<std::pair<uint64_t, std::string>>& Errors);

uint32_t cfgSetJumpSpeed(size_t SLHandle, double Speed);
uint32_t cfgSetMarkSpeed(size_t SLHandle, double Speed);

uint32_t getTrajectoryConfig(size_t SLHandle, TrajectoryConfiguration& TrajConfig);
uint32_t setTrajectoryConfig(size_t SLHandle, const TrajectoryConfiguration& Config);

uint32_t writeJob(size_t SLHandle, size_t& JobID, const CommandListType& MarkingPattern);
uint32_t writeModule(size_t SLHandle, size_t& JobID, const CartesianCoordinates& Center, const CommandListType& MarkingPattern, const char* ModuleName);
uint32_t writeCommandList(size_t SLHandle, const CommandListType& MarkingPattern);

uint32_t writeJobOnModuleList(size_t SLHandle, size_t& JobID, const std::vector<CartesianCoordinates> PositionList, const char* ModuleFile);

uint32_t startJob(size_t SLHandle);
uint32_t startJob(size_t SLHandle, bool& AutoStart);

uint32_t getJobCharacteristic(size_t SLHandle, std::map<slsc_JobCharacteristic, std::pair<std::string, double>>& JobChars, size_t JobID);

uint32_t laserOn(size_t SLHandle);
uint32_t laserOff(size_t SLHandle);
uint32_t setToManualPositioningMode(size_t SLHandle);
uint32_t setTosyncAXISMode(size_t SLHandle);
uint32_t moveStage(size_t SLHandle, const CartesianCoordinates& Target, double Speed);
uint32_t moveScanner(size_t SLHandle, const CartesianCoordinates& Target);
uint32_t resetAllRtcs(const std::string& ProgramPath);
