***************************************************************************
File: README.txt

SCANLAB syncAXIS Configurator Software Package Version 1.5.

***************************************************************************

Manufacturer

   SCANLAB GmbH
   Siemensstr. 2a 
   82178 Puchheim
   Germany

   Tel. + 49 (89) 800 746-0
   Fax: + 49 (89) 800 746-199

   info@scanlab.de
   www.scanlab.de

***************************************************************************

Scope of this Document 
> Package Description
> Licence Agreements 3rd Party

***************************************************************************

Package Description

This package contains the following files:
|   License_MIT.txt
|   License_Ms-PL.txt
|   OxyPlot.dll
|   OxyPlot.Wpf.dll
|   Readme.txt
|   ReleaseNotes.txt
|   Scanlab.SyncAxisConfig.Model.dll
|   syncAXIS_Configurator.exe
|   syncAXIS_Configurator.exe.config
|   syncAXIS_V1.5._Configurator_de-DE.pdf
|   syncAXIS_V1.5._Configurator_en-US.pdf
|   Xceed.Wpf.AvalonDock.dll
\---Xceed.Wpf.Toolkit.dll

***************************************************************************

Licence Agreements 3rd Party

* OxyPlot (LICENCE)
Licensed under the MIT License (MIT)
* Extended WPF Toolkit (LICENCE)
Licensed under the Microsoft Public License (Ms-PL)
