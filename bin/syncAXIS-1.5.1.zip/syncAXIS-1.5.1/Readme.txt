***************************************************************************
File: README.txt

SCANLAB syncAXIS control Software Version 1.5.1

***************************************************************************

Manufacturer

   SCANLAB GmbH
   Siemensstr. 2a 
   82178 Puchheim
   Germany

   Tel. + 49 (89) 800 746-0
   Fax: + 49 (89) 800 746-199

   info@scanlab.de
   www.scanlab.de

***************************************************************************

Scope of this Document 
> Package Description
> Licence Agreements 3rd Party

***************************************************************************

Package Description

The syncAXIS control software contains the following files:
|   Readme.txt
|   ReleaseNotes.txt
|   syncAXIS_control_License_Agreement.pdf
|   syncAXIS_control_Lizenzvertrag.pdf
|   syncAXIS_V1.5.1_API_de-DE.pdf
|   syncAXIS_V1.5.1_API_en-US.pdf
|   syncAXIS_V1.5.1_Installation_de-DE.pdf
|   syncAXIS_V1.5.1_Installation_en-US.pdf
|
+---Demo
|   |   CMakeLists.txt
|   |   GenerateCMakeTestProject.bat
|   |   ResetBuild.bat
|   |   syncAXIS.cmake
|   |
|   +---Configuration_Files
|   |
|   \---Installation_Project
|       |   CMakeLists.txt
|       |   IncludePath.h.in
|       |
|       +---include
|       |       ConfigFileSearch.h
|       |       DemoFunctions.h
|       |       InputTypes.h
|       |       Jobs.h
|       |       MainLoop.h
|       |       MarkingPatterns.h
|       |       OperationTypesProcedures.h
|       |       syncAXISControl.h
|       |
|       \---source
|       |       ConfigFileSearch.cpp
|       |       DemoFunctions.cpp
|       |       InputTypes.cpp
|       |       Jobs.cpp
|       |       Main.cpp
|       |       MainLoop.cpp
|       |       MarkingPatterns.cpp
|       |       OperationTypesProcedures.cpp
|       |       syncAXISControl.cpp
|
+---Licences
|       APACHE-LICENSE-2.0.txt
|       spdlog-Licence.txt
|       MPL-2.0-Licence.txt
|
+---RTC6
|   |   RTC6_Doc.Rev.1.0.9_de-DE.pdf
|   |   RTC6_Doc.Rev.1.0.9_en-US.pdf
|   |
|   +---Driver
|   |   |   RTC6DRV.inf
|   |   |   rtc6drvx64.cat
|   |   |   RTC6DRVx64.sys
|   |   |   rtc6drvx86.cat
|   |   |   RTC6DRVx86.sys
|   |   |
|   |   +---AfterInstallation
|   |   |       ReadMe_ScanlabClassChecker.pdf
|   |   |       ScanlabClassChecker.cmd
|   |   |
|   |   +---amd64
|   |   |       WdfCoInstaller01009.dll
|   |   |
|   |   \---x86
|   |           WdfCoInstaller01009.dll
|   |
|   +---ProgramFiles
|   |       RTC6Dat.dat
|   |       RTC6ETH.out
|   |       RTC6OUT.out
|   |       RTC6RBF.rbf
|   |
|   \---Tools
|       +---iSCANcfg
|       |       Handbuch_iSCANcfg_v1-7.pdf
|       |       iSCANcfg.exe
|       |       Manual_iSCANcfg_v1-7.pdf
|       |       RTC6Dat.dat
|       |       RTC6DLL.dll
|       |       RTC6ETH.out
|       |       RTC6OUT.out
|       |       RTC6RBF.rbf
|       |       RTCHalDLL.dll
|       |
|       +---RTC6conf
|       |       RTC6BIOSETH_28.out
|       |       RTC6BIOSOUT_23.out
|       |       RTC6conf.exe
|       |       RTC6conf.pdf
|       |       RTC6Dat.dat
|       |       RTC6DLL.dll
|       |       RTC6ETH.out
|       |       RTC6OUT.out
|       |       RTC6RBF.rbf
|       |
|       \---SleepMode
|               ReadMe_SleepMode.pdf
|               SleepMode.cmd
|
+---syncAXIS_control
|   +---bin
|   |   +---dll
|   |   |      RTC6DLL.dll
|   |   |      syncAXIS.dll
|   |   |      xerces-c_3_2.dll
|   |   |
|   |   +---lib
|   |   |      syncAXIS.lib
|   |   |
|   |   \---Wrapper
|   |       \---C#
|   |             syncAXIS.NET.dll
|   |             syncAXISWrapper.dll  
|   +---bin64
|   |   +---dll
|   |   |      RTC6DLLx64.dll
|   |   |      syncAXIS.dll
|   |   |      xerces-c_3_2.dll
|   |   |
|   |   +---lib
|   |   |      syncAXIS.lib
|   |   |
|   |   \---Wrapper
|   |       \---C#
|   |             syncAXIS.NET.dll
|   |             syncAXISWrapper.dll
|   |
|   +---Configuration
|   |       syncAXIS_1_5.xsd
|   |       syncAXISConfig.Template.xml
|   |       syncAXISConfig_MultiHead.Template.xml
|   |
|   |
|   \---include
|   |       syncAXIS.h
|   |       syncAXISDefinitions.h
|
\---Tools
    +---syncAXIS_Configurator
    |       License_MIT.txt
    |       License_Ms-PL.txt
    |       OxyPlot.dll
    |       OxyPlot.Wpf.dll
    |       Readme.txt
	|       ReleaseNotes.txt
    |       Scanlab.SyncAxisConfig.Model.dll
    |       syncAXIS_Configurator.exe
    |       syncAXIS_Configurator.exe.config
    |       syncAXIS_V1.5.1_Configurator_de-DE.pdf
    |       syncAXIS_V1.5.1_Configurator_en-US.pdf
    |       Xceed.Wpf.AvalonDock.dll
    |       Xceed.Wpf.Toolkit.dll
    |
    +---syncAXIS_Installation
    |       InstallationProject.exe
    |       RTC6DLL.dll
    |       syncAXIS.dll
    |       xerces-c_3_2.dll
    |
    +---syncAXIS_MasterSlaveSynchronizer
    |       MasterSlaveSynchronizer.exe
    |       RTC6DLL.dll
    |       syncAXIS.dll
    |       syncAXIS_V1.5.1_MasterSlaveSynchronizer_de-DE.pdf
    |       syncAXIS_V1.5.1_MasterSlaveSynchronizer_en-US.pdf
    |       xerces-c_3_2.dll
    |
    \---syncAXIS_Viewer
            LICENSE
            Readme.txt
			ReleaseNotes.txt
            SciChart.Charting.dll
            SciChart.Charting.DrawingTools.dll
            SciChart.Core.dll
            SciChart.Data.dll
            SciChart.Drawing.DirectX.dll
            SciChart.Drawing.dll
            SharpDX.D3DCompiler.dll
            SharpDX.Direct3D9.dll
            SharpDX.Direct3D11.dll
            SharpDX.Direct3D11.Effects.dll
            SharpDX.dll
            SharpDX.DXGI.dll
            SharpDX.Mathematics.dll
            sharpdx_direct3d11_1_effects_x64.dll
            sharpdx_direct3d11_1_effects_x86.dll
            syncAXIS Viewer.exe
            syncAXIS_V1.5.1_Viewer_de-DE.pdf
            syncAXIS_V1.5.1_Viewer_en-US.pdf
			Xceed.Wpf.AvalonDock.dll
			Xceed.Wpf.Toolkit.dll
            
***************************************************************************

* spdlog (.\Licences\spdlog-Licence.txt)
The MIT License (MIT)

Copyright (c) 2016 Gabi Melman.                                       

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
   
* Xerces (.\Licences\APACHE-LICENSE-2.0.txt)
=========================================================================
==  NOTICE file corresponding to section 4(d) of the Apache License,   ==
==  Version 2.0, in this case for the Apache Xerces distribution.      ==
=========================================================================

This product includes software developed by
The Apache Software Foundation (http://www.apache.org/).

Portions of this software were originally based on the following:
  - software copyright (c) 1999, IBM Corporation., http://www.ibm.com.

* Netlib 

** libf2c
/****************************************************************
Copyright 1990 - 1997 by AT&T, Lucent Technologies and Bellcore.

Permission to use, copy, modify, and distribute this software
and its documentation for any purpose and without fee is hereby
granted, provided that the above copyright notice appear in all
copies and that both that the copyright notice and this
permission notice and warranty disclaimer appear in supporting
documentation, and that the names of AT&T, Bell Laboratories,
Lucent or Bellcore or any of their entities not be used in
advertising or publicity pertaining to distribution of the
software without specific, written prior permission.

AT&T, Lucent and Bellcore disclaim all warranties with regard to
this software, including all implied warranties of
merchantability and fitness.  In no event shall AT&T, Lucent or
Bellcore be liable for any special, indirect or consequential
damages or any damages whatsoever resulting from loss of use,
data or profits, whether in an action of contract, negligence or
other tortious action, arising out of or in connection with the
use or performance of this software.
****************************************************************/

** DIERCKX by Paul Dierckx, Department of Computer Science, K.U. Leuven, Celestijnenlaan 200 A, B-3001, Heverlee, Belgium
Copyright © 1996 California Institute of Technology, Pasadena, California. ALL RIGHTS RESERVED. Based on Government Sponsored Research NAS7-03001. Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met: Redistributions of source code must retain this copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. Neither the name of the California Institute of Technology (Caltech) nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
For those codes indicated with a Math a la Carte copyright, the same rules apply, except without the full force of the Caltech legal team.

* Eigen (.\Licences\MPL-2.0-Licence.txt)
Version 3.3.7, 11 December 2018
http://eigen.tuxfamily.org/index.php?title=Main_Page
  
* SWIG (http://www.swig.org/)
Used to generate Wrapper files

***************************************************************************
