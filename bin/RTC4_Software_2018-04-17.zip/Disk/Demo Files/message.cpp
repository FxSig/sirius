//  File
//      message.cpp
//
//  Abstract
//      A routine for for error reporting on the console display
//
//  Author
//      Bernhard Schrems, SCANLAB AG
//

//  Function
void ErrorMessage(short ErrorCode);

// system header file
#include <stdio.h>
#include <conio.h>



//  ErrorMessage
//
//  Description:
//
//  "ErrorMessage" is a general purpose function for reporting error returns
//  of the RTC4 on the console.
//
//
//      Parameter   Meaning
//
//      ErrorCode   An error return of a RTC4 function
//

void ErrorMessage(short ErrorCode) {
    switch(ErrorCode) {
        case 3:
            // File not found, file demaged, and so on
            printf("cannot read the file\n");
            break;
        case 4:
            // The file couldn't be read back from the RTC4
            printf("cannot verify the file\n");
            break;
        case 6:
            printf("odd number of bytes in the Intel hex file\n");
            break;
        case 7:
            printf("checksum error in the Intel hex file\n");
            break;
        case 8:
            printf("system driver not found\n");
            printf("\tor locked by another application\n");
            break;
        case 9:
            printf("program file not complete\n");
            break;
        case 10:
            printf("parameter error\n");
            break;
        case 11:
            printf("RTC4 not found\n");
            break;
        case 12:
            printf("trying to load a 3D correction file\n");
            printf("\t(the 3D option is not installed)\n");
            break;
        case 13:
            // Table for the variable polygon delay not found
            printf("specified table not found\n");
            break;
        default:
            printf("code %d\n", ErrorCode);
    }
    printf("- press any key to shut down \n");
    while(!kbhit()) ;
    (void)getch();
}
