SCANLAB getRTC Software Readme

***************************************************************************

The program getRTC.exe is supplied for checking the RTC installation
and for retrieving a list of installed RTC3 or RTC4 boards.

***************************************************************************

Manufacturer
        SCANLAB AG
        Siemensstr. 2a
        82178 Puchheim
        Germany

        Tel.    + 49 (89) 800 746-0
        Fax:    + 49 (89) 800 746-199

        info@scanlab.de
        www.scanlab.de

***************************************************************************

How to use:

- getRTC requires no separate files and there is no need for a
  getRTC installation.

- Simply start getRTC.


***************************************************************************
NOTE:
Windows Vista or a later system may display the following error, when
you run getRTC.exe:

    Program Compatibility Assistant
 
        This program might not have installed correctly

The following two options are available with this message:

    * Reinstall using recommended settings
    * This program installed correctly

Solution
    If you receive this message, click the option

        This program installed correctly.
***************************************************************************

