SCANLAB RTC4 Software Readme

***************************************************************************

The RTC4 interface board in combination with the software driver
is designed for scan system and laser control in real time by an
IBM compatible PC.

The software drivers are designed for the 32-bit or 64-bit versions of the
Microsoft operating systems WINDOWS 10 / 8 / 7 / Vista / XP and for the
Microsoft operating system WINDOWS 2000. They support RTC4's plug and play
capability and simultaneously drive up to 16 RTC4 boards.

Files of the RTC4 software package are listed below. Additionally the
procedure for installing the drivers and the correspondent DLL and 
DSP program files is described in detail in this Readme file. Further
instructions for a successful operation of the RTC4 board are given in the
RTC4 manual.

***************************************************************************

Manufacturer
        SCANLAB AG
        Siemensstr.�2a�
        82178 Puchheim
        Germany

        Tel.    + 49 (89) 800 746-0
        Fax:    + 49 (89) 800 746-199

        info@scanlab.de
        www.scanlab.de

***************************************************************************

Package Description

The RTC4 software contains the following files:

1. Package and Installation Description Files
   Readme.txt           this file
   Liesmich.txt         Description in German

2. Correction Files
   cor_1to1.ctb         1:1 correction file (no field correction)
   D2_n.ctb             (optional) 2D correction file
                        n:      number of the correction file
                        -----------------------------------------------
                        Earlier 2D correction files were called
                                XXYYYZZZ.ctb with
                        XX:     aperture in [mm]
                        YYY:    focal length of the objective in [mm]
                        ZZZ:    calibration factor K in [Bits per mm]
                                (in the image field)
                        -----------------------------------------------
   D2_n_ReadMe.txt      (optional) ReadMe file as description of the
                        corresponding correction file including the
                        calibration factor K in [Bits per mm]
   D3_n.ctb             (optional) 3D correction file
                        n:      number of the correction file
   D3_n_ReadMe.txt      (optional) ReadMe file as description of the
                        corresponding correction file including the
                        calibration factor K in [Bits per mm]

3. Demo Files
   Demo programs and source code in the C language;
   Demo 3 in the C# language.

4. HPGL Converter Program
   HPGL demo application (needs HEX files and the DLL in the same
   directory).

5. iSCANConfig Program
   The program "iSCANcfg.exe" is a diagnosis and configuration program for
   the intelliSCAN, intelliDRILL or intelliWELD
   (needs HEX files and the DLL in the same directory).

6. WINDOWS Drivers, DLL, HEX and Utility Files

 a) WINDOWS Drivers for WINDOWS 10 / 8 / 7 / Vista / XP / 2000:
   SLRTCDRV.cat         catalog file
   slrtcdrv.inf         driver installation file
   SLRTCDRV.SYS         (non-signed) driver file for WINDOWS 2000
   slrtcdrvx64.cat      signed catalog file
   SLRTCDRVx64.SYS      signed 64-bit driver file
   slrtcdrvx86.cat      signed catalog file
   SLRTCDRVx86.SYS      signed 32-bit driver file

   Notice that the name of the signer of the signed files is:
   "SCANLAB AG".
   
   Security installation script for driver upgrades and description:
   AfterInstallation/ScanlabClassChecker.cmd
   AfterInstallation/ReadMe_ScanlabClassChecker.pdf
   
   Notes on Power Policy:
   Notes/NotesOnPowerPolicy.pdf

 b) RTC Files:

 - DLL File:
   RTC4DLL.DLL          32-bit RTC4 dynamic link library
                        (version number 452)
   RTC4DLLx64.DLL       64-bit RTC4 dynamic link library
                        (version number 452)

   Note:
   The RTC4DLLx64.dll requires an installation of the current
   driver release (6.1.7600.16385 from 18-Mar-16) or better.

 - DSP Program Files (HEX Files):
   RTC4D2.HEX           RTC4 program file for 2D applications
                        (version number 2442)
   RTC4D3.HEX           RTC4 program file for 3D applications
                        (version number 3442)

 c) Utility Files: 

 - for C/C++:  
   RTC4DLL.lib          32-bit Visual C++ import library for implicit
                        linking of the DLL
   RTC4DLLx64.lib       64-bit Visual C++ import library for implicit
                        linking of the DLL
   RTC4expl.cpp         C functions of the DLL handling for explicit
                        linking
   RTC4expl.h           C function prototypes of the RTC4 for explicit
                        linking of the DLL
   RTC4impl.h           C function prototypes of the RTC4 for implicit
                        linking of the DLL

 - for Basic:
   RTC4Import.bas       import declarations for Visual Basic

 - for Visual Basic .NET:
   RTC4Import.vb        import declarations for Visual Basic .NET

 - for Visual C#:
   RTC4Wrap.cs          import declarations for C#.
                        Compiling for the platform:
                        'Any CPU' allows to run your assembly under
                        32-bit or 64-bit operating systems, as well.

 - for Delphi:
   RTC4Import.pas       import declarations for Delphi

***************************************************************************

Installation Description


WINDOWS 10 / 8 Installation

For Microsoft's WINDOWS 10 / 8 operating system you need to perform the
following to get the RTC4 installed.

   1. Insert the RTC device.
   2. Start the computer.
   3. Explicitly call WINDOWS' Device Manager. Find entry 'PCI device'
      in the device tree the Device Manager displays and update its driver
      by specifying the directory 'Windows\Drivers' in the RTC4 software
      package.
      Notice the hints in the ReadMe_ScanlabClassChecker.pdf, if you
      perform an upgrade instead of a new installation of the driver.
   4. Copy the DLL file RTC4DLL.DLL (and if required the RTC4DLLx64.DLL)
      for WINDOWS 10/8/7/Vista/XP/2000 to the directory in which the
      application software will be started, or to the WINDOWS directory
      'Windows\System32'.
   6. Copy the RTC4 DSP program file(s) (*.HEX) and the correction file(s)
      (*.CTB) to the hard-disk of your PC (existing correction files can
      still be used; do not overwrite customized correction files).
      SCANLAB recommends storing these files in the directory in which the
      application software will be started.


WINDOWS 7 / Vista / XP / 2000 Installation

For installing new RTC4 drivers for WINDOWS 7, Vista, WINDOWS XP or
WINDOWS 2000 proceed as follows:

   1. Insert the RTC device.
   2. Start the computer.
   3. If the "Add Hardware Wizard" or Device Manager does not come up
      automatically, call him from the Control Panel.
   4. In the "Add Hardware Wizard" or in the Device Manager specify the
      directory 'Windows\Drivers' in the RTC4 software package.
      Notice the hints in the ReadMe_ScanlabClassChecker.pdf, if you
      perform an upgrade instead of a new installation of the driver.
   5. Copy the DLL file RTC4DLL.DLL (and if required the RTC4DLLx64.DLL)
      for WINDOWS 10/8/7/Vista/XP/2000 to the directory in which the
      application software will be started, or to the WINDOWS directory
      'Windows\System32'.
   6. Copy the RTC4 DSP program file(s) (*.HEX) and the correction file(s)
      (*.CTB) to the hard-disk of your PC (existing correction files can
      still be used; do not overwrite customized correction files).
      SCANLAB recommends storing these files in the directory in which the
      application software will be started.


Notes:
    - Run the file 'ScanlabClassChecker.cmd' in directory
      'Windows\Drivers\AfterInstallation' as administrator, if you have
      performed an upgrade instead of a new installation of the RTC4
      driver. Notice the hints in the ReadMe_ScanlabClassChecker.pdf for
      this purpose.
    - RTC4 boards cannot be used simultaneously with RTC3 boards.
    - Win32-based applications can be used with 64-bit Windows systems
      directly. Therefore they will use the same 32-bit DLL RTC4DLL.dll as
      with 32-bit systems.
      For Win64-based applications use the 64-bit DLL RTC4DLLx64.dll
      instead.
    - The power supply of the RTC4 must not be turned off as long the RTC4
      is in use by an application. Otherwise, the RTC4 setting will be lost.
      For that reason, the RTC4 driver prevents automatically initiated
      standby states during a RTC4 application. The driver, however, is not
      able to prevent forced sleep request from the shutdown menu.
      Therefore, the shutdown menu's options 'Sleep' and 'Hibernate' should
      be disabled by a corresponding setting of the Power Manager for
      example. See NotesOnPowerPolicy.pdf for details.

***************************************************************************

Further instructions for a successful operation of the RTC4 board are
given in the RTC4 manual.

***************************************************************************
